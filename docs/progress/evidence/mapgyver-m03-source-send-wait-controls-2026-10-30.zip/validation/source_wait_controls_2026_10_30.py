"""One fixed short diagnostic per scene; never retry to find a passing sample."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
for scenario in ('Q01', 'Q02'):
    name = f'qualification-{scenario.lower()}-source-send-wait-2026-10-30'
    command = [sys.executable, '-B', 'tools/mapgyver/production_qualification.py', 'run',
               '--directory', str(root/'target'/name), '--scenario', scenario, '--adapter', '0',
               '--diagnostic', '--samples', '1', '--warmup', '5', '--seconds', '5', '--isolation-seconds', '1']
    with (root/'target'/(name+'.log')).open('xb') as output:
        result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT, timeout=180)
    print(scenario, result.returncode, flush=True)
    if result.returncode:
        sys.exit(result.returncode)
