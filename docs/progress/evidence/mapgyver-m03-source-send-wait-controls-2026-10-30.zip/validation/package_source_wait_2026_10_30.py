"""Archive the versioned source policy and reconstruct GPU/source-marker evidence."""
from pathlib import Path
import hashlib
import json
import runpy
import zipfile

root = Path(__file__).resolve().parents[1]
destination = root/'docs/progress/evidence'
load = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
token = lambda t: (t['device']['runtime'], t['device']['generation'], t['serial'])
image = lambda v: (v['shared_handle'], v['frame'])
distribution = runpy.run_path(str(root/'tools/mapgyver/production_qualification.py'))['distribution']
previous_path = destination/'mapgyver-m03-output-branch-2026-10-30.json'
previous = load(previous_path)
assert sha((root/previous['archive']['path']).read_bytes()) == previous['archive']['sha256']
members, reports, identities = {}, [], {}
for phase in ('baseline', 'source_wait'):
    for scenario in ('Q01', 'Q02'):
        suffix = 'output-srgb-branch' if phase == 'baseline' else 'source-send-wait'
        parent = root/f'target/qualification-{scenario.lower()}-{suffix}-2026-10-30'
        raw = parent/'sample-001'
        analysis = load(parent/'analysis.json')
        capture = analysis['captures'][0]
        assert analysis['schema_version'] == (7 if phase == 'baseline' else 8)
        assert not analysis['qualified'] and not analysis['prescribed_three_sample_series']
        manifest = capture['manifest']
        assert manifest['adapter'] == {'high': 0, 'low': 93226}
        assert tuple(manifest[k] for k in ('warmup_seconds','sample_seconds','independence_seconds')) == (5,5,1)
        fingerprints = capture['input_fingerprints']
        assert fingerprints['unchanged'] and fingerprints['before'] == fingerprints['after']
        identity = fingerprints['before']
        if phase in identities:
            assert identity['execution_input_sha256'] == identities[phase]['execution_input_sha256']
            assert identity['executable_sha256'] == identities[phase]['executable_sha256']
        identities[phase] = identity
        for name, digest in capture['raw_sha256'].items():
            assert sha((raw/name).read_bytes()) == digest, name
        rows = [json.loads(line) for line in (raw/'renderer.jsonl').read_text().splitlines()]
        events = [row['event'] for row in rows if row['kind'] == 'diagnostic']
        sample = next(w for w in load(raw/'renderer-summary.json')['phase_windows'] if w['name']=='sample')
        inside = lambda qpc: sample['begin_qpc'] <= qpc < sample['end_qpc']
        gpu = {token(e['Gpu']['token']): e['Gpu'] for e in events if 'Gpu' in e and e['Gpu']['context']=='Renderer'}
        partitions = capture['renderer_gpu']['stage_partitions']
        verified = 0
        for record in partitions['records']:
            if record['missing'] is not None:
                continue
            row = gpu[token(record['token'])]
            assert row['status']=='Valid' and row['frequency']>0
            points = [row[k] for k in ('begin','renderer_inputs_end','renderer_render_end','end')]
            assert points == sorted(points)
            ticks = [b-a for a,b in zip(points,points[1:])]
            assert sum(ticks) == row['end']-row['begin']
            assert record['stage_ms'] == dict(zip(('inputs','render','outputs'), [t*1000/row['frequency'] for t in ticks]))
            verified += 1
        uses = {(token(e['SourceUse']['token']),e['SourceUse']['texture']):e['SourceUse'] for e in events if 'SourceUse' in e}
        producers, source_waits, send_calls = [], [], []
        for number in (1,2):
            source_rows = [json.loads(line) for line in (raw/f'source-{number}.jsonl').read_text().splitlines()]
            initial = next(row for row in source_rows if row['kind']=='source_config')
            final = next(row for row in source_rows if row['kind']=='source_final')
            if phase == 'source_wait':
                assert initial['source']['send_access_timeout_ms'] == final['source']['send_access_timeout_ms'] == 2
            source_waits.append({'source':number,'requested_ms_per_lock':initial['source'].get('send_access_timeout_ms'),
                                 'final_admission_busy':final['source']['admission_busy'],
                                 'final_missed_fixture_deadlines':final['missed_fixture_deadlines']})
            versions = {}
            frame_rows = [row for row in source_rows if row['kind']=='source_frame']
            frames = [row['submission'] for row in frame_rows]
            for record in frame_rows:
                frame = record['submission']
                if frame['outcome']=='Accepted':
                    version = image(frame['spout_image'])
                    assert version not in versions
                    versions[version] = record
            producers.append(versions)
            calls = {token(row['event']['Output']['token']):row['event']['Output']['consumer_api']
                     for row in source_rows if row['kind']=='diagnostic' and 'Output' in row['event']}
            selected = [frame for frame in frames if inside(frame['stamp']['qpc'])]
            covered = [calls[token(frame['token'])] for frame in selected if calls.get(token(frame['token'])) is not None]
            send_calls.append({'source':number,'expected_frame_records':len(selected),'covered_api_intervals':len(covered),
                               'unknown_api_intervals':len(selected)-len(covered),
                               'api_wall':distribution([(c['end']-c['begin'])*1000/manifest['qpc_frequency'] for c in covered])})
        consumers = [row['frame'] for row in map(json.loads,(raw/'consumer.jsonl').read_text().splitlines()) if row['kind']=='consumer_frame']
        accepted = [e['Output'] for e in events if 'Output' in e and e['Output']['output']==2
                    and e['Output']['outcome']=='Accepted' and inside(e['Output']['delivery']['end'])]
        captured, missing = 0, []
        for output in accepted:
            matches = [frame for frame in consumers if frame['spout_image'] and image(frame['spout_image'])==image(output['spout_image'])]
            if not matches:
                missing.append(output['token'])
                continue
            expected = [producers[n][image(uses[token(output['token']),n+1]['publication']['spout_image'])] for n in range(2)]
            for frame in matches:
                assert frame['raw_words'] == expected[0]['marker_words']+expected[1]['marker_words']
                assert frame['left'] == {'Ok':expected[0]['submission']['stamp']}
                assert frame['right'] == {'Ok':expected[1]['submission']['stamp']}
            captured += 1
        reports.append({'phase':phase,'scenario':scenario,'manifest':manifest,'renderer_gpu':{k:v for k,v in capture['renderer_gpu'].items() if k!='stage_partitions'},
                        'stage_partitions':{k:v for k,v in partitions.items() if k!='records'},
                        'outputs':capture['outputs'],'producers':capture['producers'],'source_policy':source_waits,'source_api_calls':send_calls,
                        'spout':{k:v for k,v in capture['spout_output_cohort'].items() if k not in ('records','source_publication_age')},
                        'resources':{k:v for k,v in capture['resources'].items() if k not in ('renderer_handle_counts','fixture_process_memory')},
                        'independent_audit':{'gpu_partitions_verified':verified,'expected_spout_images':len(accepted),
                                             'exact_spout_images_verified':captured,'missing_images':missing},
                        'criteria':capture['criteria'],'raw_sha256':capture['raw_sha256'],'qualified':False})
        if phase == 'source_wait':
            for path in sorted(parent.rglob('*')):
                if path.is_file():
                    members['native/'+path.relative_to(root/'target').as_posix()] = path.read_bytes()
for name, digest in identities['source_wait']['execution_input_sha256'].items():
    data = (root/name).read_bytes()
    assert sha(data)==digest, name
    members['execution-source/'+name] = data
assert sha((root/'target/release/native_qualification.exe').read_bytes()) == identities['source_wait']['executable_sha256']
for name in ('LICENSE','SPOUTSDK/licence.txt'):
    members['execution-source/vendor/spout2-sys-0.1.1/vendor/Spout2/'+name] = (root/'vendor/spout2-sys-0.1.1/vendor/Spout2'/name).read_bytes()
members['execution-source/vendor/spout2-sys-0.1.1/GOLDEN_PATCH.md'] = (root/'vendor/spout2-sys-0.1.1/GOLDEN_PATCH.md').read_bytes()
validation = root/'target/qualification-source-send-wait-validation-2026-10-30'
results = load(validation/'results.json')
assert all(result['exit_code']==0 for result in results.values())
for path in validation.iterdir():
    members['validation/'+path.name] = path.read_bytes()
native_log = (validation/'native-tests.log').read_text()
lineage = json.JSONDecoder().raw_decode(native_log.split('COPY_LINEAGE ',1)[1])[0]
assert [row['send_access_timeout_ms'] for row in lineage['keyed_access']] == [0,2]
assert all(row['busy_outcome']=='Busy' and row['counter_after_resume']==2 and not row['mismatches'] for row in lineage['keyed_access'])
for name in ('validate_source_wait_2026_10_30.py','source_wait_controls_2026_10_30.py',Path(__file__).name):
    members['validation/'+name] = (root/'target'/name).read_bytes()
archive = destination/'mapgyver-m03-source-send-wait-controls-2026-10-30.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,data in members.items():
        output.writestr(name,data)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None and len(check.namelist())==len(members)
    assert all(check.read(name)==data for name,data in members.items())
packet = {'schema_version':1,'native_artifact_schema_version':8,'date':'2026-10-30',
          'checkpoint':'Explicit finite source-worker send ownership waits; renderer send remains nonblocking',
          'source_baseline_commit':'869316847d441b415ea51316eed91bf8b2648cb8',
          'acceptance':{'M03_done':7,'M03_total':9,'complete_phases':3,'total_phases':10,'qualification_gate_closed':False},
          'policy':{'source_requested_ms_per_lock':2,'renderer_requested_ms_per_lock':0,'source_rate_hz':60,'source_processes':2,
                    'whole_call_wall_bound':False,'hidden_retries':False,'pacing_changed':False,'budget_or_denominator_changed':False},
          'baseline':{'packet':previous_path.relative_to(root).as_posix(),'sha256':sha(previous_path.read_bytes()),'archive':previous['archive']},
          'input_fingerprints':identities,'captures':reports,'native_keyed_access':lineage['keyed_access'],
          'archive':{'path':archive.relative_to(root).as_posix(),'bytes':archive.stat().st_size,'members':len(members),'sha256':sha(archive.read_bytes())},
          'validation':{'ordinary_rust_tests':154,'golden_native_tests':17,'app_native_tests':2,'python_tests':275,
                        'strict_golden_clippy':True,'release_build':True,'both_rust_formatters':True,'vendor_patch_hashes':9},
          'limitations':['one short diagnostic per scene, compared with previously published controls; not an isolated whole-renderer causal claim or prescribed-series qualification',
                         'schema 7 baseline has no timeout metadata; its zero-wait implementation remains in the linked baseline source evidence',
                         'per-lock requested timeout does not establish whole-call wall time, shutdown bounds or a calibrated GPU critical path',
                         'context/stage GPU spans include waits and CPU command-feed gaps; percentiles are never added',
                         'accepted native API calls do not prove software display deadlines or physical scanout',
                         'source admission_busy/missed_fixture_deadlines are complete-run counters, not exact sample-slot identities',
                         'full GPU/queue, cadence/age/growth and genuine device removal/stuck retirement remain open']}
with (destination/'mapgyver-m03-source-send-wait-2026-10-30.json').open('x',encoding='utf-8',newline='\n') as output:
    json.dump(packet,output,indent=2,allow_nan=False)
    output.write('\n')
print(json.dumps({'archive':packet['archive'],'audits':[r['independent_audit'] for r in reports]}))
