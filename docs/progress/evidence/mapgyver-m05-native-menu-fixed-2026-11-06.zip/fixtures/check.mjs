import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import path from 'node:path';
import { captureAlignment, ownedWindowHandle } from '../../apps/mapgyver/tests/browser/capture-alignment.mjs';
const require = createRequire(path.resolve('packages/golden-video-ui/package.json'));
const { chromium } = require('playwright-core');
const directory = path.resolve(process.argv[2]);
const stage = process.argv[3];
assert(['baseline', 'menu-open', 'recovered'].includes(stage));
const ready = JSON.parse(await readFile(path.join(directory, 'ready.json'), 'utf8'));
const sender = `MapGyver-M1110-menu-${ready.reference.screen}`;
if (stage === 'baseline') {
  const session = await fetch(`${ready.base}/api/ui/session`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}', signal: AbortSignal.timeout(5000) });
  assert(session.ok);
  const { token } = await session.json();
  const response = await fetch(`${ready.base}/api/ui/intent`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify({ kind: 'invokeAppOperation', namespace: 'mapgyver.screens', operation: 'edit', payload: { kind: 'ConfigureScreen', screen: ready.reference.screen, definition: { enabled: true, target: { kind: 'Spout', sender, extent: { width: 800, height: 600 } } } } }), signal: AbortSignal.timeout(5000) });
  assert(response.ok);
  const result = await response.json();
  assert(result.success);
  await writeFile(path.join(directory, 'sender-setup.json'), JSON.stringify({ sender, result }, null, 2));
}
let alignment, footer;
if (stage === 'menu-open') {
  const baseline = JSON.parse(await readFile(path.join(directory, 'baseline-result.json'), 'utf8'));
  const hwnd = ownedWindowHandle(ready.pid);
  assert.equal(Number(hwnd), baseline.alignment.hwnd);
  const output = path.join(directory, stage);
  execFileSync('python', ['apps/mapgyver/tests/native/window_capture.py', '--visible', '--hwnd', hwnd, '--pid', String(ready.pid), output], { windowsHide: true });
  const capture = JSON.parse(await readFile(path.join(output, 'capture.json'), 'utf8'));
  for (const key of ['desktop_bounds', 'client_desktop_origin', 'window_dpi', 'monitor_bounds']) assert.deepEqual(capture[key], baseline.alignment.capture[key]);
  await writeFile(path.join(output, 'geometry-reference.json'), JSON.stringify(baseline.alignment.geometry));
  const script = `import sys,json; from pathlib import Path; from PIL import Image; sys.path.insert(0,'apps/mapgyver/tests/native'); from visible_zoom import independent_landmark_alignment; p=Path(sys.argv[1]); v=independent_landmark_alignment(Image.open(p/'baseline.png'),json.loads((p/'geometry-reference.json').read_text()),json.loads((p/'capture.json').read_text()),sys.argv[2]); assert v['settled_alignment_verified'],v; print(json.dumps(v))`;
  const measured = JSON.parse(execFileSync('python', ['-c', script, output, ready.editor], { encoding: 'utf8', windowsHide: true }));
  alignment = { pid: ready.pid, hwnd: Number(hwnd), capture, geometry: baseline.alignment.geometry, alignment: measured, basis: 'Physical menu-open image/overlay; prior settled projection reference, identical OS bounds/DPI. WebView debug access is suspended; no fresh DOM measurement is claimed.' };
  footer = { state: 'Not sampled: native menu suspends WebView IPC/debug access' };
} else {
const browser = await chromium.connectOverCDP(ready.cdp, { timeout: 5000 });
const pages = browser.contexts().flatMap(context => context.pages()).filter(page => page.url().startsWith(ready.base + '/'));
assert.equal(pages.length, 1);
const page = pages[0];
footer = await page.locator('.video-runtime').evaluate(element => ({ state: element.dataset.state, sequence: Number(element.dataset.sequence), text: element.textContent }));
assert.equal(footer.state, 'Running');
alignment = await captureAlignment({ directory, stage, page });
}
const sdkDirectory = path.join(directory, `sdk-${stage}`);
const sdk = JSON.parse(execFileSync(path.resolve('target/debug/native_qualification-m1110.exe'), ['--role', 'calibration-pixels', '--adapter', String(ready.adapter.index), '--name', sender, '--directory', sdkDirectory], { encoding: 'utf8', windowsHide: true, timeout: 15000 }));
assert.deepEqual(sdk, { width: 800, height: 600, retired: true });
if (stage !== 'baseline') {
  assert((await readFile(path.join(directory, 'sdk-baseline/pixels.png'))).equals(await readFile(path.join(sdkDirectory, 'pixels.png'))), 'Independent output pixels must remain byte-identical');
  const baseline = JSON.parse(await readFile(path.join(directory, 'baseline-result.json'), 'utf8'));
  assert.deepEqual(alignment.geometry, baseline.alignment.geometry, 'No geometry change during native menu');
  if (stage === 'recovered') assert(footer.sequence > baseline.footer.sequence, 'Runtime status recovers after native menu');
}
const result = { stage, footer, alignment, sdk, sender };
await writeFile(path.join(directory, `${stage}-result.json`), JSON.stringify(result, null, 2));
console.log(JSON.stringify({ stage, pid: ready.pid, hwnd: alignment.hwnd, footer, alignment: alignment.alignment, sdk }));
process.exit(0);
