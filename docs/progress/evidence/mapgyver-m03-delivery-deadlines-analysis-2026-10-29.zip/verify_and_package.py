"""Recompute deadline classifications from immutable schema-6 raw observations."""
from collections import Counter, defaultdict
from fractions import Fraction
import csv
import hashlib
import io
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
RAW_ARCHIVE = ROOT/'docs/progress/evidence/mapgyver-m03-window-present-controls-2026-10-29.zip'
RAW_SHA = 'd12a5f49a23e708e8c3396a9d6e5c8445d37789425729fbc6aa1eefcbaf63de4'
TOOLS = ['production_qualification.py', 'production_deadlines.py', 'production_delivery_deadlines.py',
         'production_cohort.py', 'production_presentmon.py']
NANO = 1_000_000_000


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def key(value):
    return json.dumps(value, sort_keys=True)


def ceil(value, divisor):
    return (value+divisor-1)//divisor


def audit(directory, derived):
    manifest = read(directory/'manifest.json')
    summary = read(directory/'renderer-summary.json')
    window = next(p for p in summary['phase_windows'] if p['name'] == 'sample')
    rows = [json.loads(line) for line in (directory/'renderer.jsonl').read_text().splitlines()]
    native = defaultdict(list)
    for row in rows:
        if row['kind'] == 'diagnostic':
            for name, event in row['event'].items(): native[name].append(event)
    groups = defaultdict(list)
    for row in native['Schedule']:
        if 'Qpc' in row['clock']:
            groups[(key(row['device']), row['cadence'])].append(row)
    candidates = [group for group in groups.values()
                  if group[0]['clock']['Qpc']['anchor_qpc'] <= window['begin_qpc'] and any(
                      r['disposition'] == 'Fence' and r['clock']['Qpc']['observed_qpc_lower'] >= window['end_qpc']
                      for r in group)]
    assert len(candidates) == 1
    group = candidates[0]
    first, frequency = group[0], manifest['qpc_frequency']
    origin, anchor = first['clock']['Qpc']['origin_qpc'], first['anchor_monotonic_ns']
    deadline = lambda i: origin+ceil((anchor+ceil((i+1)*NANO, 60))*frequency, NANO)
    maximum = max(0, ((window['end_qpc']-origin)*NANO//frequency-anchor)*60//NANO)+3
    expected = [(i, deadline(i)) for i in range(maximum)
                if window['begin_qpc'] <= deadline(i) < window['end_qpc']]
    assert len(expected) == derived['expected_slots'] == 180
    consumed = {r['frame_index']: r for r in group if r['disposition'] != 'Fence'}
    output_map = {(key(o['token']), o['output']): o for o in native['Output']}
    report = read(directory/'presentmon.json')
    assert report['exit_code'] == 0 and report['tools_unchanged']
    query = json.loads(report['live_query']['stdout'])
    assert query['status'] == 0 and all(query['statistics'][k] == 0 for k in
                                       ['events_lost', 'log_buffers_lost', 'realtime_buffers_lost'])
    csv_rows = list(csv.DictReader(io.StringIO(report['stdout'])))
    matched = {}
    calls = [o for o in native['Output'] if o['window_present'] is not None]
    for row in csv_rows:
        assert int(row['ProcessID']) == manifest['pid']
        qpc, pointer = int(row['QPCTime']), int(row['SwapChainAddress'], 16)
        found = [o for o in calls if pointer in o['window_present']['addresses']
                 and o['consumer_api']['begin'] <= qpc <= o['consumer_api']['end']]
        assert len(found) == 1
        matched[(key(found[0]['token']), found[0]['output'])] = row
    consumer = [json.loads(line) for line in (directory/'consumer.jsonl').read_text().splitlines()]
    captures = defaultdict(list)
    for row in consumer:
        if row['kind'] == 'consumer_frame': captures[key(row['frame']['spout_image'])].append(row['frame'])
    publications = {(key(r['token']), r['texture']): r for r in native['SourceUse']}
    producers = []
    for index in [1, 2]:
        by_image = defaultdict(list)
        for line in (directory/f'source-{index}.jsonl').read_text().splitlines():
            row = json.loads(line)
            if row['kind'] == 'source_frame' and row['submission']['spout_image']:
                by_image[key(row['submission']['spout_image'])].append(row)
        producers.append(by_image)
    verified = []
    for result in derived['outputs']:
        output_id, counts = result['output'], Counter()
        for (index, due), record in zip(expected, result['records'], strict=True):
            assert (record['frame_index'], record['deadline_qpc']) == (index, due)
            schedule = consumed.get(index)
            if schedule is None:
                skipped = any(r['frame_index']-r['skipped_slots'] <= index < r['frame_index'] for r in group)
                fenced = any(r['disposition'] == 'Fence' and index >= r['frame_index'] for r in group)
                verdict = 'Miss' if skipped or fenced else 'Unknown'
            elif schedule['disposition'] != 'Submitted': verdict = 'Miss'
            else:
                token = key(schedule['token'])
                output = output_map.get((token, output_id))
                if output is None: verdict = 'Unknown'
                elif output['outcome'] != 'Accepted': verdict = 'Miss'
                elif output_id != 2:
                    row = matched.get((token, output_id))
                    if row is None: verdict = 'Miss' if output['consumer_api']['begin'] > due else 'Unknown'
                    elif row['Dropped'] == '1': verdict = 'Miss'
                    else:
                        displayed = Fraction(int(row['QPCTime']))+Fraction(row['msUntilDisplayed'])*frequency/1000
                        verdict = 'OnTime' if displayed <= due else 'Miss'
                else:
                    expected_sources = []
                    for source in [1, 2]:
                        use = publications.get((token, source))
                        pub = use.get('publication') if use else None
                        matches = producers[source-1].get(key(pub['spout_image']), []) if pub else []
                        if not use or not use['sequence'] or len(matches) != 1:
                            expected_sources = []
                            break
                        expected_sources.append(matches[0])
                    valid = []
                    for frame in captures[key(output['spout_image'])]:
                        if not expected_sources: continue
                        if all(frame[name] == {'Ok': expected_sources[i]['submission']['stamp']} and
                               frame['raw_words'][i*6:i*6+6] == expected_sources[i]['marker_words']
                               for i, name in enumerate(['left', 'right'])):
                            valid.append(frame['completion_observed_qpc'])
                    if valid and min(valid) <= due: verdict = 'OnTime'
                    elif output['consumer_api']['begin'] > due: verdict = 'Miss'
                    else: verdict = 'Unknown'
            assert verdict == record['classification'], (output_id, index, verdict, record)
            counts[verdict] += 1
        assert all(counts[k] == result['counts'].get(k, 0) for k in ['OnTime', 'Miss', 'Unknown'])
        verified.append({'output': output_id, 'expected': len(expected), 'counts': dict(counts)})
    return {'independent_nested_ceil_slots_and_raw_endpoint_witnesses_agree': True,
            'expected_slots': len(expected), 'outputs': verified}


assert sha(RAW_ARCHIVE) == RAW_SHA
with zipfile.ZipFile(RAW_ARCHIVE) as z:
    assert z.testzip() is None
    for name in z.namelist(): assert z.read(name) == (ROOT/'target'/name).read_bytes(), name
captures, provenance, audits = [], {}, {}
for q in ['q01', 'q02']:
    directory = ROOT/f'target/qualification-{q}-window-present-utf16-2026-10-29/sample-001'
    destination = HERE/f'{q}-final-analysis.json'
    run = subprocess.run(['python', '-B', str(ROOT/'tools/mapgyver/production_qualification.py'), 'analyze',
                          str(directory), '--diagnostic', '--output', str(destination)], capture_output=True, text=True)
    assert run.returncode == 0, run.stderr
    c = read(destination)['captures'][0]
    assert 'artifact_error' not in c
    inputs = c['input_fingerprints']['before']
    changed = []
    for path, before in inputs['execution_input_sha256'].items():
        if sha(ROOT/path) != before:
            assert path.startswith('tools/mapgyver/') and Path(path).name in TOOLS, path
            changed.append(path)
    assert sha(ROOT/'target/release/native_qualification.exe') == inputs['executable_sha256']
    provenance[q.upper()] = {'capture_analysis_inputs_changed': changed,
                            'all_other_captured_execution_hashes_still_match': True,
                            'native_executable_unchanged': True, 'new_native_capture': False}
    audits[q.upper()] = audit(directory, c['delivery_deadlines'])
    captures.append({'scenario': q.upper(), 'delivery_deadlines': c['delivery_deadlines'],
                     'deadline_criterion': c['criteria']['deadline_misses'],
                     'original_inputs': c['input_fingerprints'], 'raw_sha256': c['raw_sha256']})
(HERE/'independent-audit.json').write_text(json.dumps(audits, indent=2)+'\n', encoding='utf-8', newline='\n')
archive = ROOT/'docs/progress/evidence/mapgyver-m03-delivery-deadlines-analysis-2026-10-29.zip'
assert not archive.exists()
members = [HERE/'q01-final-analysis.json', HERE/'q02-final-analysis.json', HERE/'independent-audit.json',
           HERE/'verify_and_package.py', HERE/'python-tests.log']
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in members: z.write(path, path.name)
packet = {'schema_version': 1, 'native_artifact_schema_version': 6, 'date': '2026-10-29',
          'checkpoint': 'Anchored window delivery deadlines and conservative Spout GPU-ready bounds',
          'source_baseline_commit': 'e273da3b81f8e2f2f38535c5212097f0a4b49993',
          'acceptance': {'M03_done': 7, 'M03_total': 9, 'complete_phases': 3, 'total_phases': 10,
                         'qualification_gate_closed': False},
          'raw_capture_archive': {'path': RAW_ARCHIVE.relative_to(ROOT).as_posix(), 'sha256': RAW_SHA,
                                  'unchanged': True, 'new_native_workload_run': False},
          'derived_archive': {'path': archive.relative_to(ROOT).as_posix(), 'bytes': archive.stat().st_size,
                              'sha256': sha(archive), 'members': len(members)},
          'analysis_source_sha256': {name: sha(ROOT/'tools/mapgyver'/name) for name in TOOLS},
          'provenance': provenance, 'validation': {'production_python_tests': 85,
              'native_runtime_changed': False, 'rust_formatters_run': True, 'independent_raw_reconstruction': audits},
          'scope': 'Offline reanalysis of the existing short Intel Q01/Q02 schema-6 captures; native code, binaries, inputs and original analyses remain unchanged',
          'limitations': ['Three-second diagnostic samples do not satisfy prescribed native qualification.',
                         'Late completion polling is not a GPU deadline miss; straddling ready intervals remain unknown.',
                         'Software window display is not physical scanout, optical latency or GPU critical-path proof.',
                         'M03 native queue, GPU critical path, growth/handles and genuine removal/stuck retirement remain open.'],
          'captures': captures}
destination = ROOT/'docs/progress/evidence/mapgyver-m03-delivery-deadlines-2026-10-29.json'
assert not destination.exists()
destination.write_text(json.dumps(packet, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({'derived_archive': packet['derived_archive'], 'audits': audits, 'provenance': provenance}))
