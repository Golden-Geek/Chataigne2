use super::*;
use windows::Win32::Foundation::{HANDLE, S_OK};
use windows::Win32::Graphics::Direct3D11::*;
use windows::Win32::Graphics::Dxgi::Common::{DXGI_FORMAT_R8G8B8A8_TYPELESS, DXGI_SAMPLE_DESC};
use windows::Win32::Graphics::Dxgi::IDXGIKeyedMutex;

use crate::native::device::{Device, adapters};
use crate::native::pipeline::Pipeline;
use crate::native::tests::pixels::readback;
use crate::plan::{BlendMode, SampleFilter};
use crate::{AlphaMode, ColorEncoding, Extent2D};

struct ReadGuard(IDXGIKeyedMutex);
impl Drop for ReadGuard {
    fn drop(&mut self) {
        // SAFETY: this test acquired key 0, and its finite readback completed before release.
        unsafe { self.0.ReleaseSync(0) }.unwrap();
    }
}

#[test]
#[ignore = "requires hardware D3D11 and an owned Spout sender"]
fn hardware_srgb_conversion_keeps_typed_wire_pixels_and_rejects_invalid_copies() {
    let adapter = adapters()
        .unwrap()
        .into_iter()
        .find(|adapter| !adapter.software)
        .unwrap();
    let gpu = Device::new(adapter.id).unwrap();
    let reader = Device::new(adapter.id).unwrap();
    let pipeline = Pipeline::new(&gpu.device).unwrap();
    for format in [PixelFormat::Rgba8Unorm, PixelFormat::Bgra8Unorm] {
        let wire = TextureDescriptor {
            extent: Extent2D::new(4, 1).unwrap(),
            format,
            color_encoding: ColorEncoding::Srgb,
            alpha_mode: AlphaMode::Opaque,
        };
        let linear = Texture::new(
            &gpu.device,
            TextureDescriptor {
                color_encoding: ColorEncoding::Linear,
                alpha_mode: AlphaMode::Premultiplied,
                ..wire
            },
        )
        .unwrap();
        let converted = Texture::new_output(&gpu.device, wire).unwrap();
        let mut sender =
            SpoutOutput::new(&gpu.device, format!("GoldenOutputView-{}", uuid::Uuid::new_v4()), wire).unwrap();
        // SAFETY: owned linear source. Production shader composites coverage over black.
        unsafe {
            gpu.context
                .ClearRenderTargetView(&linear.rtv, &[0.0625, 0.125, 0.25, 0.5])
        };
        pipeline.draw(
            &gpu.context,
            &linear,
            None,
            (&converted).into(),
            1.0,
            BlendMode::Normal,
            SampleFilter::Nearest,
        );
        assert_eq!(sender.deliver(&converted, None, &mut None), Delivery::Accepted);
        let image = sender.copied_image_version().unwrap();
        assert_eq!(image.frame, 1);
        // The finite readback's event fences the preceding SDK copy on this same context.
        let expected_pixels = readback(&gpu, &converted);
        let expected = [0.0625_f64, 0.125, 0.25].map(|value| {
            (if value <= 0.0031308 {
                value * 12.92
            } else {
                1.055 * value.powf(1.0 / 2.4) - 0.055
            }) * 255.0
        });
        for pixel in &expected_pixels {
            for channel in 0..3 {
                assert!((f64::from(pixel[channel]) - expected[channel]).abs() <= 2.0);
            }
            assert_eq!(pixel[3], 255);
        }
        let mut imported = None;
        // SAFETY: live legacy Spout handle owned by sender; no offline/foreign handles are opened.
        unsafe {
            reader
                .device
                .OpenSharedResource::<windows::Win32::Graphics::Direct3D11::ID3D11Texture2D>(
                    HANDLE(image.shared_handle as i32 as isize as *mut _),
                    &mut imported,
                )
                .unwrap();
        }
        let imported = imported.unwrap();
        let mut desc = D3D11_TEXTURE2D_DESC::default();
        unsafe { imported.GetDesc(&mut desc) };
        assert_eq!(desc.Format, super::format(format), "wire remains fully typed UNORM");
        let mutex: IDXGIKeyedMutex = imported.cast().unwrap();
        let acquired = unsafe { (mutex.vtable().AcquireSync)(mutex.as_raw(), 0, 0) };
        assert_eq!(acquired, S_OK);
        let guard = ReadGuard(mutex);
        let shared = Texture::from_native(&reader.device, imported, wire).unwrap();
        assert_eq!(
            readback(&reader, &shared),
            expected_pixels,
            "cross-device wire copy preserves encoded bytes"
        );
        drop(guard);

        let wrong_format = match format {
            PixelFormat::Rgba8Unorm => DXGI_FORMAT_B8G8R8A8_UNORM,
            PixelFormat::Bgra8Unorm => DXGI_FORMAT_R8G8B8A8_UNORM,
        };
        let foreign = Texture::new(&reader.device, wire).unwrap();
        let mut mipmapped = None;
        unsafe {
            gpu.device
                .CreateTexture2D(
                    &D3D11_TEXTURE2D_DESC {
                        Width: 4,
                        Height: 2,
                        MipLevels: 2,
                        ArraySize: 1,
                        Format: super::format(format),
                        SampleDesc: DXGI_SAMPLE_DESC { Count: 1, Quality: 0 },
                        Usage: D3D11_USAGE_DEFAULT,
                        ..Default::default()
                    },
                    None,
                    Some(&mut mipmapped),
                )
                .unwrap();
        }
        let mipmapped = mipmapped.unwrap();
        for (texture, declared) in [
            (converted.texture.as_raw(), wrong_format),
            (converted.texture.as_raw(), DXGI_FORMAT_R8G8B8A8_TYPELESS),
            (foreign.texture.as_raw(), super::format(format)),
            (mipmapped.as_raw(), super::format(format)),
            (std::ptr::null_mut(), super::format(format)),
        ] {
            let status =
                unsafe { sdk::spout_dx_send_texture_as_status(sender.raw.as_ptr(), texture, declared.0 as u32) };
            assert_eq!(status, sdk::SPOUT_DX_TRANSFER_FAILED);
            assert_eq!(
                sender.copied_image_version(),
                Some(image),
                "rejected copy cannot replace/advance the shared image"
            );
        }
        unsafe { gpu.context.ClearState() };
    }
}
