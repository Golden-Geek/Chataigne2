"""Archive paired output conversion controls and independently reconstruct GPU/marker joins."""
from pathlib import Path
import hashlib
import json
import math
import statistics
import zipfile

root = Path(__file__).resolve().parents[1]
destination = root/'docs/progress/evidence'
load = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
key = lambda token: (token['device']['runtime'], token['device']['generation'], token['serial'])
image = lambda version: (version['shared_handle'], version['frame'])
members, reports, inputs = {}, [], {}

def distribution(values):
    values = sorted(values)
    if not values: return None
    return {'samples': len(values), **{name: values[math.ceil(len(values)*p/100)-1]
            for name, p in [('median_ms',50),('p95_ms',95),('p99_ms',99),('maximum_ms',100)]}}

for phase in ('before', 'after', 'branch'):
    for scenario in ('Q01', 'Q02'):
        parent = root/f'target/qualification-{scenario.lower()}-output-srgb-{phase}-2026-10-30'
        raw = parent/'sample-001'
        analysis = load(parent/'analysis.json')
        current = analysis['captures'][0]
        assert analysis['schema_version'] == 7 and not analysis['qualified']
        manifest = current['manifest']
        assert manifest['adapter'] == {'high':0,'low':93226}
        assert (manifest['warmup_seconds'], manifest['sample_seconds'], manifest['independence_seconds']) == (5,5,1)
        fingerprints = current['input_fingerprints']
        assert fingerprints['unchanged'] and fingerprints['before'] == fingerprints['after']
        identity = fingerprints['before']
        if phase in inputs:
            assert inputs[phase]['execution_input_sha256'] == identity['execution_input_sha256']
            assert inputs[phase]['executable_sha256'] == identity['executable_sha256']
        inputs[phase] = identity
        if phase in ('after', 'branch'):
            for name, digest in identity['execution_input_sha256'].items():
                path = root/name if phase == 'branch' else root/'target/qualification-output-srgb-rejected-source-2026-10-30'/name
                assert sha(path.read_bytes()) == digest, name
            if phase == 'branch':
                assert sha((root/'target/release/native_qualification.exe').read_bytes()) == identity['executable_sha256']
        for name, digest in current['raw_sha256'].items(): assert sha((raw/name).read_bytes()) == digest
        rows = [json.loads(line) for line in (raw/'renderer.jsonl').read_text().splitlines()]
        events = [row['event'] for row in rows if row['kind'] == 'diagnostic']
        window = next(r for r in load(raw/'renderer-summary.json')['phase_windows'] if r['name'] == 'sample')
        inside = lambda qpc: window['begin_qpc'] <= qpc < window['end_qpc']
        gpu = {key(e['Gpu']['token']): e['Gpu'] for e in events if 'Gpu' in e and e['Gpu']['context'] == 'Renderer'}
        partitions = current['renderer_gpu']['stage_partitions']
        whole, stages = [], {stage: [] for stage in ('inputs','render','outputs')}
        verified_gpu = 0
        for record in partitions['records']:
            if record['missing'] is not None: continue
            row = gpu[key(record['token'])]
            assert row['status'] == 'Valid' and row['frequency'] > 0
            points = [row[k] for k in ('begin','renderer_inputs_end','renderer_render_end','end')]
            assert all(type(p) is int for p in points) and points == sorted(points)
            ticks = [b-a for a,b in zip(points, points[1:])]
            assert sum(ticks) == row['end']-row['begin']
            derived = dict(zip(stages, [t*1000/row['frequency'] for t in ticks]))
            assert record['stage_ms'] == derived
            for stage, value in derived.items(): stages[stage].append(value)
            whole.append((row['end']-row['begin'])*1000/row['frequency'])
            verified_gpu += 1
        assert {k: distribution(v) for k,v in stages.items()} == partitions['stages']
        assert distribution(whole) == current['renderer_gpu']['context_local_execution']
        uses = {(key(e['SourceUse']['token']),e['SourceUse']['texture']): e['SourceUse'] for e in events if 'SourceUse' in e}
        producers = []
        for number in (1,2):
            source = [json.loads(line) for line in (raw/f'source-{number}.jsonl').read_text().splitlines()]
            versions = {}
            for row in source:
                if row['kind'] == 'source_frame' and row['submission']['outcome'] == 'Accepted':
                    version = image(row['submission']['spout_image'])
                    assert version not in versions
                    versions[version] = row
            producers.append(versions)
        consumers = [json.loads(line)['frame'] for line in (raw/'consumer.jsonl').read_text().splitlines()
                     if json.loads(line)['kind'] == 'consumer_frame']
        accepted = [e['Output'] for e in events if 'Output' in e and e['Output']['output'] == 2
                    and e['Output']['outcome'] == 'Accepted' and inside(e['Output']['delivery']['end'])]
        captured, missing = 0, []
        for output in accepted:
            matches = [frame for frame in consumers if frame['spout_image']
                       and image(frame['spout_image']) == image(output['spout_image'])]
            if not matches:
                missing.append(output['token'])
                continue
            expected = [producers[n][image(uses[key(output['token']),n+1]['publication']['spout_image'])] for n in range(2)]
            for frame in matches:
                assert frame['raw_words'] == expected[0]['marker_words']+expected[1]['marker_words']
                assert frame['left'] == {'Ok':expected[0]['submission']['stamp']}
                assert frame['right'] == {'Ok':expected[1]['submission']['stamp']}
            captured += 1
        snapshots = [row['runtime']['resources'] for row in rows if row['kind'] == 'snapshot' and row['runtime']['resources']]
        base = min(r['bytes_used']-r['active']['bytes'] for r in snapshots
                   if r['initialized'] and r['active'] and r['prepared'] == r['retiring'] == 0)
        assert base == (80179264 if scenario == 'Q01' else 254361664)
        reports.append({'phase':phase, 'scenario':scenario, 'manifest':manifest,
            'renderer_gpu':{k:v for k,v in current['renderer_gpu'].items() if k != 'stage_partitions'},
            'stage_partitions':{k:v for k,v in partitions.items() if k != 'records'},
            'outputs':current['outputs'], 'producers':current['producers'],
            'spout':{k:v for k,v in current['spout_output_cohort'].items() if k not in ('records','source_publication_age')},
            'resources':{k:v for k,v in current['resources'].items() if k not in ('renderer_handle_counts','fixture_process_memory')},
            'constant_reservation_bytes':base, 'criteria':current['criteria'],
            'independent_audit':{'gpu_partitions_verified':verified_gpu,
                                 'expected_accepted_spout_images':len(accepted), 'exact_spout_images_verified':captured,
                                 'missing_spout_images':missing, 'raw_input_hashes_stable':True},
            'raw_sha256':current['raw_sha256'], 'qualified':False})
        for path in sorted(parent.rglob('*')):
            if path.is_file(): members['native/'+path.relative_to(root/'target').as_posix()] = path.read_bytes()

for folder in ('qualification-output-srgb-validation-2026-10-30','qualification-output-srgb-final-validation-2026-10-30',
               'qualification-output-srgb-branch-validation-2026-10-30','qualification-output-srgb-branch-reviewed-validation-2026-10-30'):
    directory = root/'target'/folder
    if folder != 'qualification-output-srgb-branch-validation-2026-10-30':
        assert all(result['exit_code'] == 0 for result in load(directory/'results.json').values())
    for path in sorted(directory.iterdir()): members['validation/'+folder+'/'+path.name] = path.read_bytes()
rejected_source = root/'target/qualification-output-srgb-rejected-source-2026-10-30'
for path in sorted(rejected_source.rglob('*')):
    if path.is_file(): members['rejected-source/'+path.relative_to(rejected_source).as_posix()] = path.read_bytes()
for name in ('vendor/spout2-sys-0.1.1/vendor/Spout2/LICENSE',
             'vendor/spout2-sys-0.1.1/vendor/Spout2/SPOUTSDK/licence.txt'):
    members['rejected-source/'+name] = (root/name).read_bytes()
for name in ('srgb_output_controls_2026_10_30.py','validate_output_srgb_2026_10_30.py','preserve_rejected_output_srgb_2026_10_30.py',
             'finish_output_branch_validation_2026_10_30.py',
             'output-srgb-current-shader.asm','output-srgb-current-shader.cso',
             'output-srgb-branched-shader.asm','output-srgb-branched-shader.cso'):
    members['validation/'+name] = (root/'target'/name).read_bytes()
members['validation/'+Path(__file__).name] = Path(__file__).read_bytes()
log = (root/'target/qualification-output-srgb-branch-reviewed-validation-2026-10-30/native-tests.log').read_text()
start = log.index('OUTPUT_TRANSFER_TIMING ')+len('OUTPUT_TRANSFER_TIMING ')
isolated = json.JSONDecoder().raw_decode(log[start:])[0]
isolated['flattened_median_ms'] = statistics.median(isolated['flattened_gpu_ms_per_draw'])
isolated['branched_median_ms'] = statistics.median(isolated['branched_gpu_ms_per_draw'])
isolated['median_change_fraction'] = isolated['branched_median_ms']/isolated['flattened_median_ms']-1
isolated['median_definition'] = 'ordinary median; average of two middle values for these even-sized samples'
archive = destination/'mapgyver-m03-output-branch-controls-2026-10-30.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,data in members.items(): output.writestr(name,data)
with zipfile.ZipFile(archive) as check:
    assert len(check.namelist()) == len(members) and check.testzip() is None
    assert all(check.read(name) == data for name,data in members.items())
packet = {'schema_version':1,'native_artifact_schema_version':7,'date':'2026-10-30',
    'checkpoint':'Coherent opaque output transfer branch; hardware Spout conversion rejected and removed',
    'source_baseline_commit':'a56a0a928022a481f0ad47e6449353ec8c210642',
    'acceptance':{'M03_done':7,'M03_total':9,'complete_phases':3,'total_phases':10,'qualification_gate_closed':False},
    'archive':{'path':archive.relative_to(root).as_posix(),'sha256':sha(archive.read_bytes()),
               'bytes':archive.stat().st_size,'members':len(members)},
    'input_fingerprints':inputs, 'captures':reports, 'isolated_draw_control': isolated,
    'validation':{'ordinary_rust_tests':153,'golden_native_tests':17,'app_native_tests':2,
                  'python_tests':267,'strict_golden_clippy':True,'release_build':True,
                  'finite_output_color_cases':96,'isolated_draw_pairs':12},
    'rejected_experiment':{'phase':'after','runtime_and_SDK_changes_removed':True,
                           'typed_wire_pixel_comparisons':8,'rejected_sdk_copies':10,
                           'execution_sources_archived':len(inputs['after']['execution_input_sha256'])},
    'changes':['Explicit uniform shader branch skips unused opaque gamma instructions for linear shader targets',
               'Ninety-six independent finite transfer/alpha/opacity cases and paired isolated GPU draw control',
               'No production SDK, texture-format, resource admission or queue change'],
    'limitations':['Short sequential diagnostic controls, not prescribed three-sample qualification',
                   'Rejected combined output/view/branch experiment does not isolate each contribution',
                   'GPU context/stage spans include waits and command-feed gaps; stage percentiles are not summed',
                   'No full GPU critical path, GPU queue, native occupancy or software/physical display measurement',
                   'Earlier validations cover the rejected implementation; branch-reviewed covers the final source',
                   'A test-only COM output-slot compile error is retained; repaired before branch-reviewed validation',
                   'FXC assembly controls retain the pre-existing X3571 and X4000 shader diagnostics'],
    'references':['https://learn.microsoft.com/en-us/windows/win32/api/d3d11/nf-d3d11-id3d11devicecontext-copyresource',
                  'https://learn.microsoft.com/en-us/windows/win32/direct3dhlsl/dx-graphics-hlsl-if']}
with (destination/'mapgyver-m03-output-branch-2026-10-30.json').open('x',encoding='utf-8',newline='\n') as output:
    json.dump(packet,output,indent=2,allow_nan=False)
    output.write('\n')
print(json.dumps({'archive':packet['archive'],'audits':[r['independent_audit'] for r in reports]}))
