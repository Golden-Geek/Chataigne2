import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
directory = root/'target/qualification-output-srgb-rejected-source-2026-10-30'
directory.mkdir(exist_ok=False)
inputs = json.loads((root/'target/qualification-q02-output-srgb-after-2026-10-30/sample-001/inputs.json').read_text())['before']
for name, digest in inputs['execution_input_sha256'].items():
    data = (root/name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == digest
    path = directory/name
    path.parent.mkdir(exist_ok=True, parents=True)
    path.write_bytes(data)
(directory/'changes.patch').write_bytes(subprocess.check_output(['git','diff','--binary'], cwd=root))
print('Preserved', len(inputs['execution_input_sha256']), 'rejected execution sources')
