from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parents[1]
directory = root/'target/qualification-output-srgb-branch-reviewed-validation-2026-10-30'
results = json.loads((directory/'results.json').read_text())
commands = {'root-format': ['cargo','fmt','--all'],
            'golden-core-format': ['cargo','fmt','--all','--manifest-path','crates/golden_core/Cargo.toml'],
            'diff-check': ['git','diff','--check']}
for name, command in commands.items():
    with (directory/(name+'.log')).open('xb') as log:
        result = subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=90)
    assert result.returncode == 0
    results[name] = {'command':command,'exit_code':result.returncode}
vendor = root/'vendor/spout2-sys-0.1.1'
patches = json.loads((vendor/'PATCHES.json').read_text())
hash_file = lambda path: hashlib.sha256(path.read_bytes().replace(b'\r\n',b'\n')).hexdigest()
assert all(hash_file(vendor/e['path']) == e['patched_sha256'] for e in patches['files'])
assert all(hash_file(vendor/p) == digest for p,digest in patches['documentation'].items())
assert not subprocess.check_output(['git','diff','--name-only','--','vendor/spout2-sys-0.1.1'],cwd=root).strip()
results['vendor-unchanged'] = {'exit_code':0,'scope':'all tracked vendor changes removed; normalized patch/documentation hashes match'}
with (directory/'results.json').open('w',encoding='utf-8') as output:
    json.dump(results,output,indent=2)
print('Both formatters, whitespace, unchanged vendor and all patch hashes verified')
