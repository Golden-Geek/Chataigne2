"""Package bounded native evidence; independently reconstruct exact GPU-marker joins."""

from collections import Counter, defaultdict
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[2]
CHECKS = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'docs/progress/evidence'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def rows(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def key(value):
    return json.dumps(value, sort_keys=True)


def independently_check(directory, analysis):
    native = [r['event'] for r in rows(directory / 'renderer.jsonl') if r['kind'] == 'diagnostic']
    outputs = [e['Output'] for e in native if 'Output' in e]
    uses = {(key(e['SourceUse']['token']), e['SourceUse']['texture']): e['SourceUse']
            for e in native if 'SourceUse' in e}
    producers = []
    for source in (1, 2):
        images = defaultdict(list)
        for r in rows(directory / f'source-{source}.jsonl'):
            if r['kind'] == 'source_frame' and r['submission']['spout_image']:
                images[key(r['submission']['spout_image'])].append(r)
        producers.append(images)
    received, captures = {}, defaultdict(list)
    for r in rows(directory / 'consumer.jsonl'):
        if r['kind'] == 'consumer_frame':
            captures[key(r['frame']['spout_image'])].append(r['frame'])
        elif r['kind'] == 'diagnostic' and 'SourceCpu' in r['event']:
            payload = r['event']['SourceCpu']
            received[key(payload['token'])] = payload
    versions = Counter(key(o['spout_image']) for o in outputs
                       if o['output'] == 2 and o['outcome'] == 'Accepted')
    summary = read(directory / 'renderer-summary.json')
    reports = []
    for window in summary['phase_windows']:
        if window['name'] not in ('sample', 'editor_minimized', 'editor_disconnected'):
            continue
        oracle = (analysis['spout_output_cohort'] if window['name'] == 'sample' else
                  next(p['spout_output_cohort'] for p in analysis['independence']['phases']
                       if p['phase'] == window['name']))
        selected = [o for o in outputs if o['output'] == 2 and o['outcome'] == 'Accepted'
                    and window['begin_qpc'] <= o['delivery']['end'] < window['end_qpc']]
        assert len(selected) == oracle['expected_accepted_images']
        complete, absent, bad, mismatches = 0, 0, Counter(), 0
        for output, recorded in zip(selected, oracle['records'], strict=True):
            image = key(output['spout_image'])
            assert versions[image] == 1 and recorded['token'] == output['token']
            expected = []
            for index in range(2):
                use = uses.get((key(output['token']), index + 1))
                publication = use.get('publication') if use else None
                matches = producers[index].get(key(publication['spout_image']), []) if publication else []
                if not use or not use['sequence'] or len(matches) != 1:
                    expected = None
                    break
                expected.append(matches[0])
            valid = []
            for frame in captures[image]:
                receive = received[key(frame['token'])]['receive_api']
                assert receive['begin'] == frame['receive_begin_qpc']
                assert receive['end'] >= output['consumer_api']['begin']
                assert frame['completion_observed_qpc'] >= receive['end']
                if expected is None:
                    bad['missing or ambiguous exact producer/source-use image'] += 1
                elif any(frame[name] != {'Ok': expected[i]['submission']['stamp']}
                         or frame['raw_words'][6*i:6*i+6] != expected[i]['marker_words']
                         for i, name in enumerate(('left', 'right'))):
                    bad['GPU marker differs from the exact renderer source image'] += 1
                    mismatches += 1
                else:
                    valid.append(frame)
            if valid:
                complete += 1
                first = min(valid, key=lambda f: f['completion_observed_qpc'])
                assert recorded['capture_row'] == first['row'] and recorded['missing'] is None
                ages = [(first['completion_observed_qpc'] - r['submission']['stamp']['qpc']) * 1000
                        / summary['qpc_frequency'] for r in expected]
                assert ages == recorded['source_ages_ms']
            else:
                absent += 1
                assert recorded['missing'] is not None
        assert complete == oracle['captured_images'] and absent == oracle['missing_images']
        assert bad == Counter(r['reason'] for r in oracle['invalid_captures'])
        reports.append({'phase': window['name'], 'accepted': len(selected), 'exact': complete,
                        'missing': absent, 'pixel_lineage_mismatches': mismatches,
                        'invalid_capture_reasons': dict(bad)})
    return reports


def compact_capture(capture):
    c = deepcopy(capture)
    c.pop('other_contexts')
    c['native_preparation'].pop('records')
    c['spout_output_cohort'].pop('records')
    for p in c['independence']['phases']:
        p['spout_output_cohort'].pop('records')
    return c


sdk = ROOT / 'vendor/spout2-sys-0.1.1'
patch = read(sdk / 'PATCHES.json')
upstream = read(sdk / 'UPSTREAM.json')
patched = {r['path']: r for r in patch['files']}
for r in upstream['files']:
    chosen = patched.get(r['path'])
    if chosen:
        assert chosen['baseline_sha256'] == r['repository_sha256']
    assert sha(sdk / r['path']) == (chosen['patched_sha256'] if chosen else r['repository_sha256'])
for path, expected in patch['documentation'].items():
    assert sha(sdk / path) == expected

checks = read(CHECKS / 'lineage.json')[0]
assert sum(v['compared'] for k, v in checks.items() if k != 'adapter') == 518
assert all(not v['mismatches'] for k, v in checks.items() if k != 'adapter')
test_lines = [l for l in (CHECKS / 'full-native-stdout.log').read_text().splitlines()
              if l.startswith('test result:')]
assert sum(int(re.search(r'(\d+) passed;', l)[1]) for l in test_lines) == 191
assert all('0 failed; 0 ignored;' in l for l in test_lines)

first_failure = read(CHECKS / 'baseline-untapped-failure.json')['output']
baseline = json.loads(first_failure.split('COPY_LINEAGE ', 1)[1].splitlines()[0])
assert len(baseline['runtime']['mismatches']) == 22
tap_raw = read(CHECKS / 'baseline-tapped-failure.json')['output']
tap_json = tap_raw.split('COPY_LINEAGE ', 1)[1]
# The PTY interleaved Rust panic stderr inside one JSON property name. Preserve the raw
# capture verbatim; remove only that known injected stderr span to read the measured report.
begin = tap_json.index('\nthread ')
end = tap_json.index('frame":3', begin)
tap_json = tap_json[:begin] + tap_json[end:]
tap_baseline = json.loads(tap_json.splitlines()[0])
assert (tap_baseline['runtime']['input_stage_mismatches'],
        tap_baseline['runtime']['conversion_stage_mismatches'],
        tap_baseline['runtime']['output_stage_mismatches']) == (0, 0, 1)

captures, roots, recomputed = [], [], {}
for scenario in ('q01', 'q02'):
    root = ROOT / f'target/qualification-{scenario}-keyed-handoff-2026-10-29'
    roots.append(root)
    c = read(root / 'analysis.json')['captures'][0]
    assert c['input_fingerprints']['unchanged']
    for path, expected in c['input_fingerprints']['before']['execution_input_sha256'].items():
        assert sha(ROOT / path) == expected, path
    assert len(c['input_fingerprints']['before']['execution_input_sha256']) == 255
    assert all(role['complete'] for role in c['criteria']['telemetry_coverage']['roles'])
    summary = read(root / 'sample-001/renderer-summary.json')
    parent = read(root / 'sample-001/parent-summary.json')
    assert summary['retirement']['actual_retirement']
    assert summary['final_runtime']['state'] == 'Stopped'
    assert summary['final_runtime']['resources']['bytes_used'] == 0
    assert summary['final_runtime']['resources']['in_flight'] == 0
    assert all(child['success'] and not child['forced'] for child in parent['children'])
    c['retirement'] = summary['retirement']
    c['owned_children'] = parent['children']
    recomputed[scenario.upper()] = independently_check(root / 'sample-001', c)
    captures.append(compact_capture(c))

archive = EVIDENCE / 'mapgyver-m03-keyed-handoff-controls-2026-10-29.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root in [*roots, CHECKS]:
        for path in sorted(root.rglob('*')):
            if path.is_file():
                z.write(path, path.relative_to(ROOT / 'target').as_posix())

packet = {
    'schema_version': 1, 'artifact_schema_version': 4, 'date': '2026-10-29',
    'checkpoint': 'GPU keyed Spout image ownership preserves copy-label/pixel lineage',
    'source_baseline_commit': 'ffc4bb9e959d529c6260a1f71ad3ecbf42287076',
    'acceptance': {'M03_done': 7, 'M03_total': 9, 'complete_phases': 3,
                   'total_phases': 10, 'qualification_gate_closed': False},
    'archive': {'path': archive.relative_to(ROOT).as_posix(), 'bytes': archive.stat().st_size,
                'sha256': sha(archive), 'members': len(zipfile.ZipFile(archive).namelist())},
    'validation': {'regular_rust_tests': 179, 'explicit_native_gpu_tests': 12,
                   'production_python_tests': 49, 'full_rust_results': test_lines,
                   'strict_default_and_native_all_target_clippy': True,
                   'release_x64_build': True, 'sdk_all_feature_all_target_check': True,
                   'legacy_desktop_probe_all_target_check': True,
                   'root_and_golden_core_formatters': True,
                   'full_rust_command': 'cargo test --locked -p golden_video -p MapGyver --features native-qualification --lib --tests -- --include-ignored --test-threads=1 --nocapture',
                   'sdk_baseline_files_verified': len(upstream['files']),
                   'sdk_patch_files_verified': len(patched),
                   'current_execution_fingerprints_verified_per_capture': 255,
                   'independent_raw_cohort_recomputation': recomputed},
    'scope': {'adapter': 'Intel adapter0 LUID 00000000:00016c2a', 'samples_per_scenario': 1,
              'warmup_seconds': 1, 'sample_seconds': 3, 'isolation_seconds_per_phase': 1,
              'sdk_fork_changed': True, 'driver_display_overlay_settings_changed': False,
              'reference_scenes_budgets_queue_depth_polling_changed': False},
    'isolation': {'baseline_untapped_runtime_mismatches': 22,
                  'baseline_tapped_input_mismatches': 0,
                  'baseline_tapped_conversion_mismatches': 0,
                  'baseline_tapped_output_mismatches': 1,
                  'baseline_harness_note': 'The first untapped failure also misclassified a disconnected watchdog channel as expiry; that harness error was corrected. The tapped report has PTY-interleaved panic stderr; raw output is preserved.',
                  'fixed_native_regression': checks, 'available_marker_comparisons': 518},
    'findings': [
        'Direct SDK and SourcePool bridge retain exact pixels; GPU taps locate the observed full-runtime mismatch after conversion at the outgoing SDK image handoff.',
        'Golden opts into SDK GPU keyed shared textures before initialization. Detailed sends take zero-timeout CPU metadata then GPU image ownership; Busy does not copy or advance the counter.',
        'Unchanged counter hints take only CPU metadata ownership. A held-GPU regression verifies no hint GPU submission and successful retry without counter advance on Busy.',
        'Q01 captures all 180 sample-accepted images with exact pixels; both interruption phases capture 60/60 exactly.',
        'Q02 captures 148/176 sample-accepted images with zero observed pixel mismatches; 28 remain uncaptured. Minimized captures 46/58, disconnected 36/61 with 16 missing-source captures.',
        'Q02 cadence and source age remain insufficient. No native recovery or full qualification gate closes.'
    ],
    'limitations': [
        'Finite single-source regression and short two-source controls do not qualify sustained cadence, source admission, complete capture coverage, handles or growth.',
        'GPU taps and final readback exist only in opt-in native tests, can perturb timing, and are complemented by an untapped production runtime case.',
        'CPU API acceptance and completed captures do not prove physical presentation, window age, GPU queue time or a cross-context critical path.',
        'Real device-removal and bounded stuck-driver retirement remain open under M03 gate 4.',
        'Named-mutex legacy input regression remains covered; foreign sender GPU synchronization guarantees depend on that peer. DX9 is outside the selected route.',
        'Late Spout Busy occurs inside send after conversion and may retain conversion/API intervals; only existing window preflight rejects before conversion.'
    ],
    'captures': captures,
}
packet_path = EVIDENCE / 'mapgyver-m03-keyed-handoff-2026-10-29.json'
assert not packet_path.exists()
packet_path.write_text(json.dumps(packet, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'archive': packet['archive'], 'recomputed': recomputed}))
