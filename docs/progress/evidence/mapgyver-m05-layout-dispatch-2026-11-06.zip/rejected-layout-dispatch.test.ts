import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { createPreviewSession, type PreviewGeometry, type PreviewSession } from '../session';
import type { PreviewRequest } from '../generated/PreviewRequest';
import type { PreviewResponse } from '../generated/PreviewResponse';

describe('browser-reported preview layout', () => {
	const owned: PreviewSession[] = [];
	beforeEach(() => vi.useFakeTimers());
	afterEach(async () => {
		for (const session of owned.splice(0)) void session.dispose();
		await vi.advanceTimersByTimeAsync(0);
		vi.useRealTimers();
		vi.unstubAllGlobals();
	});

	function fixture(override?: (request: PreviewRequest) => Promise<PreviewResponse> | undefined) {
		const requests: PreviewRequest[] = [];
		const session = createPreviewSession({
			available: () => true,
			async request(request) {
				requests.push(request);
				const pending = override?.(request);
				if (pending) return pending;
				if (request.kind === 'Connect')
					return {
						kind: 'Connected',
						session: 'owned',
						version: request.version,
						max_views: 64
					};
				if (request.kind === 'Layout' || request.kind === 'Status')
					return {
						kind: 'Applied',
						revision: request.revision,
						visible_views:
							request.kind === 'Layout' ? request.views.filter((v) => v.visible).length : 1,
						installed: true
					};
				return { kind: 'Disconnected' };
			}
		});
		owned.push(session);
		const geometry: PreviewGeometry = {
			rect: { x: 100, y: 100, width: 400, height: 300 },
			clip: { x: 10, y: 10, width: 800, height: 600 },
			visible: true,
			overlays: [
				{
					shape: { kind: 'Circle', center: [0.2, 0.2], radius: 6 },
					hit: 'corner',
					fill: [1, 1, 1, 1],
					stroke: [0, 0, 1, 1],
					width: 1,
					dash: null
				}
			],
			overlay_capacity: 2
		};
		const view = session.register('screen', () => geometry, { paint: () => 'native-backdrop' });
		return {
			session,
			view,
			geometry,
			requests,
			layouts: () => requests.filter((r) => r.kind === 'Layout')
		};
	}

	function frames() {
		const pending = new Map<number, FrameRequestCallback>();
		let id = 0;
		vi.stubGlobal('requestAnimationFrame', (callback: FrameRequestCallback) => {
			pending.set(++id, callback);
			return id;
		});
		vi.stubGlobal('cancelAnimationFrame', (key: number) => pending.delete(key));
		return pending;
	}

	it('measures resized native content now and cancels its obsolete queued animation callback', async () => {
		const { session, view, geometry, layouts } = fixture();
		await session.connect();
		await vi.advanceTimersByTimeAsync(0);
		const pending = frames();
		geometry.rect = { ...geometry.rect, width: 450 };
		view.invalidate();
		expect(pending.size).toBe(1);
		session.measureLayout();
		expect(pending.size).toBe(0);
		expect(layouts()).toHaveLength(2);
		expect(layouts()[1].views[0].rect.width).toBe(450);
		await vi.advanceTimersByTimeAsync(0);
		expect(session.state.installed).toBe(true);
	});

	it.each(['clip', 'scale', 'source'] as const)(
		'still waits for browser paint after %s changes',
		async (change) => {
			const { session, view, geometry, layouts } = fixture();
			await session.connect();
			await vi.advanceTimersByTimeAsync(0);
			const pending = frames();
			if (change === 'clip') geometry.clip = { ...geometry.clip, width: 700 };
			if (change === 'scale') vi.stubGlobal('devicePixelRatio', 1.5);
			if (change === 'source') view.update('replacement');
			session.measureLayout();
			expect(layouts()).toHaveLength(1);
			expect(pending.size).toBe(1);
			const [id, callback] = [...pending][0];
			pending.delete(id);
			callback(0);
			await vi.advanceTimersByTimeAsync(0);
			expect(layouts()).toHaveLength(2);
		}
	);

	it('coalesces repeated layout observations behind one real pending native request', async () => {
		let blocked = false;
		let resolve!: (response: PreviewResponse) => void;
		const reply = new Promise<PreviewResponse>((done) => {
			resolve = done;
		});
		const { session, geometry, layouts } = fixture((request) =>
			blocked && request.kind === 'Layout' ? reply : undefined
		);
		await session.connect();
		await vi.advanceTimersByTimeAsync(0);
		const pending = frames();
		blocked = true;
		geometry.rect = { ...geometry.rect, x: 90 };
		session.measureLayout();
		for (let x = 91; x <= 110; x++) {
			geometry.rect = { ...geometry.rect, x };
			session.measureLayout();
		}
		expect(layouts()).toHaveLength(2);
		expect(pending.size).toBe(0);
		blocked = false;
		resolve({ kind: 'Applied', revision: 2, visible_views: 1, installed: true });
		await vi.advanceTimersByTimeAsync(0);
		expect(layouts()).toHaveLength(3);
		expect(layouts()[2].views[0].rect.x).toBe(110);
	});

	it('withdraws an exact delayed cohort before measuring changed native placement', async () => {
		let blocked = false;
		let resolve!: (response: PreviewResponse) => void;
		const reply = new Promise<PreviewResponse>((done) => {
			resolve = done;
		});
		const { session, geometry, layouts } = fixture((request) =>
			blocked && request.kind === 'Layout' ? reply : undefined
		);
		await session.connect();
		await vi.advanceTimersByTimeAsync(0);
		blocked = true;
		await vi.advanceTimersByTimeAsync(2501);
		expect(session.state.presentedViews).toHaveLength(1);
		geometry.rect = { ...geometry.rect, x: 90 };
		session.measureLayout();
		expect(session.state.presentedViews).toEqual([]);
		expect(layouts()).toHaveLength(2);
		resolve({ kind: 'Applied', revision: 2, visible_views: 1, installed: true });
		await vi.advanceTimersByTimeAsync(0);
		expect(session.state.presentedViews).toEqual([]);
	});
});
