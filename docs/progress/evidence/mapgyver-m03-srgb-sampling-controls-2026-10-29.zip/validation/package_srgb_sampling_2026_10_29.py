"""Package immutable short controls without modifying captured evidence."""
from pathlib import Path
import hashlib
import json
import statistics
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'docs/progress/evidence'
LABELS = [('Q02 baseline', 'qualification-q02-srgb-baseline-2026-10-29'),
          ('Q02 decoded view', 'qualification-q02-srgb-hardware-2026-10-29'),
          ('Q01 decoded view', 'qualification-q01-srgb-hardware-2026-10-29')]
SOURCES = ['crates/golden_video/src/native/backend/resources.rs',
           'crates/golden_video/src/native/pipeline.rs',
           'crates/golden_video/src/native/texture.rs',
           'crates/golden_video/src/native/tests/pixels.rs']


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


captures, members = [], {}
identities = []
for label, directory in LABELS:
    parent = ROOT / 'target' / directory
    analysis = read(parent / 'analysis.json')
    assert analysis['qualified'] is False and not analysis['prescribed_three_sample_series']
    capture = analysis['captures'][0]
    inputs = capture['input_fingerprints']
    assert inputs['unchanged'] and inputs['before'] == inputs['after']
    identities.append(inputs['before'])
    raw = parent / 'sample-001'
    for name, sha in capture['raw_sha256'].items():
        assert digest((raw / name).read_bytes()) == sha, (label, name)
    for path in sorted(parent.rglob('*')):
        if path.is_file():
            members['native/' + path.relative_to(ROOT / 'target').as_posix()] = path.read_bytes()
    cohort = capture['spout_output_cohort']
    captures.append({
        'label': label, 'directory': directory, 'manifest': capture['manifest'],
        'input_fingerprints': inputs, 'raw_sha256': capture['raw_sha256'],
        'criteria': capture['criteria'], 'cpu': capture['cpu'], 'renderer_gpu': capture['renderer_gpu'],
        'outputs': capture['outputs'], 'producers': capture['producers'], 'resources': capture['resources'],
        'anchored_opportunities': capture['submission_deadlines']['expected_slots'],
        'spout': {key: cohort[key] for key in ('expected_accepted_images', 'captured_images', 'missing_images',
                                             'invalid_captures', 'coverage_complete', 'source_age')},
        'independence': capture['independence'],
        'qualified': analysis['qualified'],
    })

baseline, candidate, q01 = identities
assert candidate['execution_input_sha256'] == q01['execution_input_sha256']
assert candidate['executable_sha256'] == q01['executable_sha256']
assert digest((ROOT / 'target/release/native_qualification.exe').read_bytes()) == candidate['executable_sha256']
changed = [path for path, sha in baseline['execution_input_sha256'].items()
           if candidate['execution_input_sha256'][path] != sha]
assert set(changed) == set(SOURCES), changed
after_capture = [path for path, sha in candidate['execution_input_sha256'].items()
                 if digest((ROOT / path).read_bytes()) != sha]
assert after_capture == ['crates/golden_video/src/native/tests/pixels.rs'], after_capture
assert captures[0]['resources']['logical_reserved_peak_bytes'] == captures[1]['resources']['logical_reserved_peak_bytes']

cost_path = ROOT / 'target/qualification-srgb-sampler-cost-2026-10-29.log'
cost_text = cost_path.read_text(encoding='utf-16')
cost_json = cost_text.split('SAMPLER_TIMING ', 1)[1].split('}\n', 1)[0] + '}'
# PowerShell's retained raw stderr log wraps long lines, including inside numeric tokens.
cost = json.loads(cost_json.replace('\n', '').replace('\r', ''))
assert cost['measured_pairs'] == 12 and cost['warmup_pairs'] == 4
manual = cost['manual_decode_gpu_ms_per_draw']
decoded = cost['hardware_decode_gpu_ms_per_draw']
assert len(manual) == len(decoded) == 12
cost['manual_median_ms'] = statistics.median(manual)
cost['hardware_median_ms'] = statistics.median(decoded)
cost['median_fraction_reduction'] = 1 - cost['hardware_median_ms'] / cost['manual_median_ms']
for name in ['qualification-srgb-native-tests-2026-10-29.log', cost_path.name]:
    members['validation/' + name] = (ROOT / 'target' / name).read_bytes()
members['validation/' + Path(__file__).name] = Path(__file__).read_bytes()

archive = EVIDENCE / 'mapgyver-m03-srgb-sampling-controls-2026-10-29.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in members.items():
        output.writestr(name, data)
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None and len(output.namelist()) == len(members)
    assert all(output.read(name) == data for name, data in members.items())

packet = {
    'schema_version': 1, 'date': '2026-10-29', 'source_baseline_commit': baseline['git_head'],
    'checkpoint': 'Hardware sRGB source decoding; bounded sampler and native controls',
    'acceptance': {'M03_done': 7, 'M03_total': 9, 'complete_phases': 3, 'total_phases': 10,
                   'qualification_gate_closed': False},
    'archive': {'path': archive.relative_to(ROOT).as_posix(), 'sha256': digest(archive.read_bytes()),
                'bytes': archive.stat().st_size, 'members': len(members)},
    'final_source_sha256': {path: digest((ROOT / path).read_bytes()) for path in SOURCES},
    'changed_execution_inputs_from_baseline': sorted(changed),
    'post_capture_source_changes': {'paths': after_capture,
                                   'scope': 'cost-test addition and formatting only; production runtime and executable unchanged'},
    'isolated_sampler_cost': cost,
    'validation': {'regular_library_tests': 148, 'public_integration_tests': 4,
                   'native_regression_tests': 11, 'additional_native_cost_test': 1,
                   'strict_clippy': True, 'release_runner_build': True, 'both_rust_formatters': True,
                   'python_tests': {'retained_baseline': 85, 'rerun': False, 'analysis_source_changed': False}},
    'captures': captures,
    'limitations': ['short sequential controls, not the prescribed qualification series',
                    'isolated sampler benefit does not establish a whole-frame critical-path improvement',
                    'Q02 renderer-context GPU p95 did not improve',
                    'no PresentMon collector; window software-display/deadline observations not recaptured',
                    'Q02 cadence, missing captures, admission, GPU/queue and genuine recovery gates remain open'],
}
path = EVIDENCE / 'mapgyver-m03-srgb-sampling-2026-10-29.json'
with path.open('x', encoding='utf-8', newline='\n') as output:
    json.dump(packet, output, indent=2, allow_nan=False)
    output.write('\n')
print(json.dumps({'archive': packet['archive'], 'cost': {key: cost[key] for key in
                 ('manual_median_ms', 'hardware_median_ms', 'median_fraction_reduction')},
                 'captures': len(captures), 'source_hashes_verified': True}))
