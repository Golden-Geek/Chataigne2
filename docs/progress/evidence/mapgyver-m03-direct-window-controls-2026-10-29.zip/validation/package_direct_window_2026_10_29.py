"""Verify original baselines and final native controls without overwriting raw evidence."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT/'docs/progress/evidence'
BASE_PACKET = DEST/'mapgyver-m03-gpu-stages-2026-10-29.json'
baseline = json.loads(BASE_PACKET.read_text())
members, captures = {}, []


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def key(token):
    return token['device']['runtime'], token['device']['generation'], token['serial']


base_archive = ROOT/baseline['archive']['path']
assert sha(base_archive.read_bytes()) == baseline['archive']['sha256']
with zipfile.ZipFile(base_archive) as archive:
    assert archive.testzip() is None
    for name in archive.namelist():
        if name.startswith('native/'):
            assert archive.read(name) == (ROOT/'target'/name[len('native/'):]).read_bytes()

identities = []
for scenario, count in [('Q01', 300), ('Q02', 299)]:
    directory = ROOT/f'target/qualification-{scenario.lower()}-direct-window-2026-10-29'
    analysis = load(directory/'analysis.json')
    capture = analysis['captures'][0]
    assert analysis['schema_version'] == 7 and analysis['qualified'] is False
    assert capture['manifest']['adapter'] == {'high': 0, 'low': 93226}
    original = next(row for row in baseline['captures'] if row['scenario'] == scenario)
    for name in ['adapter', 'scenario', 'sample_seconds', 'warmup_seconds', 'independence_seconds']:
        assert capture['manifest'][name] == original['manifest'][name]
    fingerprints = capture['input_fingerprints']
    assert fingerprints['unchanged'] and fingerprints['before'] == fingerprints['after']
    inputs = fingerprints['before']
    identities.append(inputs)
    for path, digest in inputs['execution_input_sha256'].items():
        assert sha((ROOT/path).read_bytes()) == digest, path
    assert sha((ROOT/'target/release/native_qualification.exe').read_bytes()) == inputs['executable_sha256']
    raw = directory/'sample-001'
    for path, digest in capture['raw_sha256'].items():
        assert sha((raw/path).read_bytes()) == digest
    summary = load(raw/'renderer-summary.json')
    sample = next(row for row in summary['phase_windows'] if row['name'] == 'sample')
    events = [row['event'] for row in map(json.loads, (raw/'renderer.jsonl').read_text().splitlines())
              if row['kind'] == 'diagnostic']
    cpu = {key(e['FrameCpu']['token']): e['FrameCpu'] for e in events if 'FrameCpu' in e}
    frames = {identity: row for identity, row in cpu.items()
              if sample['begin_qpc'] <= row['wall']['begin'] < sample['end_qpc']}
    gpu = {}
    for event in events:
        if 'Gpu' in event and event['Gpu']['context'] == 'Renderer':
            row = event['Gpu']
            assert key(row['token']) not in gpu
            gpu[key(row['token'])] = row
    partitions = capture['renderer_gpu']['stage_partitions']
    records = {key(row['token']): row for row in partitions['records']}
    assert set(frames) == set(records) and len(frames) == count
    assert partitions['coverage_complete'] and partitions['covered_batches'] == count
    for identity in frames:
        row = gpu[identity]
        assert row['status'] == 'Valid' and row['frequency'] > 0
        points = [row[k] for k in ['begin', 'renderer_inputs_end', 'renderer_render_end', 'end']]
        assert all(type(x) is int and x >= 0 for x in points) and points == sorted(points)
        ticks = [b-a for a,b in zip(points, points[1:])]
        assert sum(ticks) == row['end']-row['begin']
        assert records[identity]['stage_ms'] == dict(zip(['inputs', 'render', 'outputs'],
                                                        [x*1000/row['frequency'] for x in ticks]))
    main = [e['Output'] for e in events if 'Output' in e and e['Output']['output'] == 1
            and e['Output']['outcome'] == 'Accepted'
            and sample['begin_qpc'] <= e['Output']['delivery']['end'] < sample['end_qpc']]
    boundary = [row for row in main if key(row['token']) not in frames]
    assert len(main) == capture['submission_deadlines']['expected_slots'] == 300
    assert len(boundary) == (1 if scenario == 'Q02' else 0)
    for row in boundary:
        assert cpu[key(row['token'])]['wall']['begin'] < sample['begin_qpc']
    cohort = capture['spout_output_cohort']
    assert cohort['coverage_complete'] and not cohort['invalid_captures']
    assert capture['native_preparation']['created_textures'] == 5
    expected_peak = 156672064 if scenario == 'Q01' else 505036864
    assert capture['resources']['logical_reserved_peak_bytes'] == expected_peak
    captures.append({
        'scenario': scenario, 'manifest': capture['manifest'], 'raw_sha256': capture['raw_sha256'],
        'execution_inputs_stable': True, 'renderer_gpu': {k:v for k,v in capture['renderer_gpu'].items()
                                                       if k != 'stage_partitions'},
        'stage_partitions': {k:v for k,v in partitions.items() if k != 'records'},
        'outputs': capture['outputs'], 'producers': capture['producers'],
        'spout': {k:cohort[k] for k in ['expected_accepted_images','captured_images','missing_images',
                                      'invalid_captures','coverage_complete','source_age']},
        'logical_reserved_peak_bytes': expected_peak, 'initial_generation_textures': 5,
        'independent_audit': {'partition_records_verified': count, 'anchored_opportunities': 300,
                              'pre_window_main_frames': boundary, 'raw_bytes_and_clocks_verified': True},
        'criteria': capture['criteria'], 'qualified': False,
    })
    for path in sorted(directory.rglob('*')):
        if path.is_file(): members['native/'+path.relative_to(ROOT/'target').as_posix()] = path.read_bytes()

assert identities[0]['execution_input_sha256'] == identities[1]['execution_input_sha256']
assert identities[0]['executable_sha256'] == identities[1]['executable_sha256']
current = identities[0]['execution_input_sha256']
previous = baseline['execution_input_sha256']
changed = [p for p in sorted(set(current)|set(previous)) if current.get(p) != previous.get(p)]
assert set(changed) == {
    'crates/golden_video/src/native/backend.rs',
    'crates/golden_video/src/native/backend/resources.rs',
    'crates/golden_video/src/native/outputs.rs',
    'crates/golden_video/src/native/outputs/window.rs',
    'crates/golden_video/src/native/outputs/window/tests/mod.rs',
    'crates/golden_video/src/native/pipeline.rs',
    'crates/golden_video/src/native/tests/pixels.rs',
}, changed
validation = ROOT/'target/qualification-direct-window-final-validation-2026-10-29'
assert all(row['exit_code'] == 0 for row in load(validation/'results.json'))
for path in sorted(validation.iterdir()): members['validation/'+path.name] = path.read_bytes()
for path in [Path(__file__), ROOT/'target/validate_direct_window_2026_10_29.py']:
    members['validation/'+path.name] = path.read_bytes()
archive_path = DEST/'mapgyver-m03-direct-window-controls-2026-10-29.zip'
with zipfile.ZipFile(archive_path, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in members.items(): output.writestr(name, data)
with zipfile.ZipFile(archive_path) as output:
    assert output.testzip() is None and len(output.namelist()) == len(members)
    assert all(output.read(name) == data for name, data in members.items())
packet = {
    'schema_version': 1, 'native_artifact_schema_version': 7, 'date': '2026-10-29',
    'checkpoint': 'Direct admitted window rendering with hardware sRGB encoding',
    'source_baseline_commit': identities[0]['git_head'],
    'acceptance': {'M03_done': 7, 'M03_total': 9, 'complete_phases': 3, 'total_phases': 10,
                   'qualification_gate_closed': False},
    'baseline': {'packet': BASE_PACKET.relative_to(ROOT).as_posix(),
                 'packet_sha256': sha(BASE_PACKET.read_bytes()), 'archive': baseline['archive'],
                 'raw_members_unchanged': True, 'captures': baseline['captures']},
    'archive': {'path': archive_path.relative_to(ROOT).as_posix(), 'sha256': sha(archive_path.read_bytes()),
                'bytes': archive_path.stat().st_size, 'members': len(members)},
    'changed_execution_inputs': changed, 'execution_input_sha256': current,
    'executable_sha256': identities[0]['executable_sha256'],
    'validation': {'ordinary_rust_tests': 152, 'native_tests': 15, 'production_python_tests': 92,
                   'strict_clippy': True, 'both_rust_formatters': True, 'final_release_runner_build': True,
                   'direct_backbuffer_pixel_frames': 6, 'pixels_per_frame': 16, 'tolerance': '2/255'},
    'captures': captures,
    'limitations': ['short sequential controls; no full qualification or broad causal inference',
                    'Q01 p99 and output p95 tails increase and are retained',
                    'Q02 editor/Spout/producer cadence and GPU cost remain insufficient',
                    'logical reservation reduction is not physical GPU residency',
                    'no calibrated queues, native buffer occupancy, full GPU critical path or new display-age proof',
                    'genuine removal/stuck retirement and the prescribed series remain open'],
}
path = DEST/'mapgyver-m03-direct-window-2026-10-29.json'
with path.open('x', encoding='utf-8', newline='\n') as output:
    json.dump(packet, output, indent=2, allow_nan=False)
    output.write('\n')
print(json.dumps({'archive': packet['archive'], 'verified_new_partitions': 599,
                  'verified_execution_hashes': len(current), 'changed_inputs': changed}))
