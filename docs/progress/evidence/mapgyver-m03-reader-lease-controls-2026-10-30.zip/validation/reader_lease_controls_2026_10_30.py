"""One post-fix control per scene, retaining exact software-display collector evidence."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
for scenario in ('Q01','Q02'):
    name = f'qualification-{scenario.lower()}-reader-lease-2026-10-30'
    command = [sys.executable,'-B','tools/mapgyver/production_qualification.py','run',
               '--directory',str(root/'target'/name),'--scenario',scenario,'--adapter','0',
               '--diagnostic','--samples','1','--warmup','5','--seconds','5','--isolation-seconds','1','--presentmon']
    with (root/'target'/(name+'.log')).open('xb') as log:
        result = subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    print(scenario,result.returncode,flush=True)
    if result.returncode:
        sys.exit(result.returncode)
