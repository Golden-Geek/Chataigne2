"""Validate slot-owned renderer leases and truthful source recovery causes."""
from pathlib import Path
import json
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
directory = root/'target/qualification-reader-lease-validation-2026-10-30'
directory.mkdir(exist_ok=False)
commands = {
    'root-format': ['cargo','fmt','--all'],
    'golden-core-format': ['cargo','fmt','--all','--manifest-path','crates/golden_core/Cargo.toml'],
    'regular-tests': ['cargo','test','--locked','-p','golden_video','--features','qualification'],
    'native-tests': ['cargo','test','--locked','-p','golden_video','--features','qualification','--lib','--','--ignored','--test-threads=1','--nocapture'],
    'app-native-tests': ['cargo','test','--locked','-p','MapGyver','--features','native-qualification','--test','channel_rendering','--test','picture_rendering','--','--ignored','--test-threads=1'],
    'clippy': ['cargo','clippy','--locked','-p','golden_video','--features','qualification','--all-targets','--','-D','warnings'],
    'release-build': ['cargo','build','--locked','--release','-p','MapGyver','--features','native-qualification','--bin','native_qualification'],
    'python-tests': [sys.executable,'-B','-m','unittest','discover','-s','tools/mapgyver/tests'],
    'diff-check': ['git','diff','--check'],
}
results = {}
for name,command in commands.items():
    with (directory/(name+'.log')).open('xb') as output:
        result = subprocess.run(command,cwd=root,stdout=output,stderr=subprocess.STDOUT)
    results[name] = {'command':command,'exit_code':result.returncode}
    (directory/'results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(name,result.returncode,flush=True)
    if result.returncode:
        sys.exit(result.returncode)
