"""Retain regression, native source continuity, exact images and software-display joins."""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import runpy
import zipfile

root = Path(__file__).resolve().parents[1]
destination = root/'docs/progress/evidence'
load = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
key = lambda t: (t['device']['runtime'],t['device']['generation'],t['serial'])
image = lambda v: (v['shared_handle'],v['frame']) if v else None
runner = runpy.run_path(str(root/'tools/mapgyver/production_qualification.py'))
distribution = runner['distribution']
baseline_path = destination/'mapgyver-m03-source-send-wait-2026-10-30.json'
baseline = load(baseline_path)
assert sha((root/baseline['archive']['path']).read_bytes()) == baseline['archive']['sha256']
members, reports, identities = {}, [], {}
for phase in ('before','fixed'):
    for scenario in ('Q01','Q02'):
        suffix = 'source-send-wait' if phase=='before' else 'reader-lease'
        parent = root/f'target/qualification-{scenario.lower()}-{suffix}-2026-10-30'
        raw = parent/'sample-001'
        analysis = load(parent/'analysis.json')
        capture = analysis['captures'][0]
        manifest = capture['manifest']
        assert analysis['schema_version']==8 and not analysis['qualified']
        assert manifest['adapter']=={'high':0,'low':93226}
        assert tuple(manifest[k] for k in ('warmup_seconds','sample_seconds','independence_seconds'))==(5,5,1)
        fp = capture['input_fingerprints']
        assert fp['unchanged'] and fp['before']==fp['after']
        current = fp['before']
        if phase in identities:
            assert identities[phase]['execution_input_sha256']==current['execution_input_sha256']
            assert identities[phase]['executable_sha256']==current['executable_sha256']
        identities[phase] = current
        if phase=='before':
            with zipfile.ZipFile(root/baseline['archive']['path']) as z:
                for name in z.namelist():
                    if name.startswith('native/'+parent.name+'/'):
                        assert z.read(name)==(parent/name[len('native/'+parent.name+'/'):]).read_bytes()
        for name,digest in capture['raw_sha256'].items():
            assert sha((raw/name).read_bytes())==digest,name
        read = lambda name: [json.loads(line) for line in (raw/name).read_text().splitlines()]
        rows = read('renderer.jsonl')
        events = [row['event'] for row in rows if row['kind']=='diagnostic']
        native = runner['events'](rows)
        sources = [read(f'source-{n}.jsonl') for n in (1,2)]
        source_images = []
        for stream in sources:
            first = next(row for row in stream if row['kind']=='source_config')
            final = next(row for row in stream if row['kind']=='source_final')
            assert first['source']['send_access_timeout_ms']==final['source']['send_access_timeout_ms']==2
            versions = {}
            for row in stream:
                if row['kind']=='source_frame' and row['submission']['outcome']=='Accepted':
                    version = image(row['submission']['spout_image'])
                    assert version not in versions
                    versions[version] = row
            source_images.append(versions)
        consumers = defaultdict(list)
        for row in read('consumer.jsonl'):
            if row['kind']=='consumer_frame':
                consumers[image(row['frame']['spout_image'])].append(row['frame'])
        uses = {(key(e['SourceUse']['token']),e['SourceUse']['texture']):e['SourceUse'] for e in events if 'SourceUse' in e}
        gpu = {key(e['Gpu']['token']):e['Gpu'] for e in events if 'Gpu' in e and e['Gpu']['context']=='Renderer'}
        verified = 0
        for record in capture['renderer_gpu']['stage_partitions']['records']:
            if record['missing'] is not None:
                continue
            row = gpu[key(record['token'])]
            assert row['status']=='Valid' and row['frequency']>0
            points = [row[k] for k in ('begin','renderer_inputs_end','renderer_render_end','end')]
            assert points==sorted(points)
            ticks = [b-a for a,b in zip(points,points[1:])]
            assert sum(ticks)==row['end']-row['begin']
            assert record['stage_ms']==dict(zip(('inputs','render','outputs'),[t*1000/row['frequency'] for t in ticks]))
            verified += 1
        windows = load(raw/'renderer-summary.json')['phase_windows']
        derived = []
        report = load(raw/'presentmon.json') if (raw/'presentmon.json').is_file() else None
        for window in windows:
            if window['name'] not in ('sample','editor_minimized','editor_disconnected'):
                continue
            inside = lambda q: q is not None and window['begin_qpc']<=q<window['end_qpc']
            frames = [e['FrameCpu'] for e in events if 'FrameCpu' in e and e['FrameCpu']['wall'] and inside(e['FrameCpu']['wall']['begin'])]
            frame_keys = {key(frame['token']) for frame in frames}
            absent = {n:sum(uses.get((t,n),{}).get('publication') is None for t in frame_keys) for n in (1,2)}
            selected = [o for o in native['Output'] if o['output']==2 and o['outcome']=='Accepted' and inside((o.get('delivery') or {}).get('end'))]
            valid, missing, unknown, mismatches = 0,[],[],[]
            for output in selected:
                matches = consumers.get(image(output['spout_image']),[])
                if not matches:
                    missing.append(output['token'])
                    continue
                expected = []
                for n in (1,2):
                    use = uses.get((key(output['token']),n))
                    pub = use.get('publication') if use else None
                    expected.append(source_images[n-1].get(image(pub.get('spout_image'))) if pub else None)
                if any(value is None for value in expected):
                    unknown.append(output['token'])
                    continue
                wrong = [frame['row'] for frame in matches if frame['raw_words']!=expected[0]['marker_words']+expected[1]['marker_words']
                         or frame['left']!={'Ok':expected[0]['submission']['stamp']} or frame['right']!={'Ok':expected[1]['submission']['stamp']}]
                if wrong:
                    mismatches.append({'token':output['token'],'capture_rows':wrong})
                else:
                    valid += 1
            software = runner['PRESENTMON']['analyze_presentmon'](report,native,sources,window,manifest['pid'],manifest['qpc_frequency'],distribution)
            audit = {'phase':window['name'],'cpu_frame_cohort':len(frames),'absent_source_use':absent,
                     'accepted_spout_images':len(selected),'exact_images_verified':valid,'missing_capture_tokens':missing,
                     'unknown_lineage_tokens':unknown,'marker_mismatches':mismatches}
            derived.append(audit)
            members[f'phase-audits/{phase}-{scenario}-{window["name"]}.json'] = (json.dumps({'audit':audit,'software_display':software},indent=2)+'\n').encode()
        summary = load(raw/'renderer-summary.json')
        reports.append({'phase':phase,'scenario':scenario,'manifest':manifest,
                        'renderer_gpu':{k:v for k,v in capture['renderer_gpu'].items() if k!='stage_partitions'},
                        'outputs':capture['outputs'],'producers':capture['producers'],
                        'sample_spout':{k:v for k,v in capture['spout_output_cohort'].items() if k not in ('records','source_publication_age')},
                        'source_snapshots':summary['active_native']['sources'],'phase_audits':derived,'gpu_partitions_verified':verified,
                        'independence':[{**{k:v for k,v in p.items() if k not in ('frame_age','spout_output_cohort')},
                                         'captured_spout_images':p['spout_output_cohort']['captured_images'],
                                         'expected_spout_images':p['spout_output_cohort']['expected_accepted_images'],
                                         'invalid_spout_captures':len(p['spout_output_cohort']['invalid_captures']),
                                         'covered_source_age_p95_ms':[v['p95_ms'] for v in p['spout_output_cohort']['source_age']]}
                                        for p in capture['independence']['phases']],
                        'resources':{k:v for k,v in capture['resources'].items() if k not in ('renderer_handle_counts','fixture_process_memory')},
                        'criteria':capture['criteria'],'qualified':False})
        if phase=='fixed':
            for path in parent.rglob('*'):
                if path.is_file():
                    members['native/'+path.relative_to(root/'target').as_posix()] = path.read_bytes()
for name,digest in identities['fixed']['execution_input_sha256'].items():
    data = (root/name).read_bytes()
    assert sha(data)==digest,name
    members['execution-source/'+name] = data
assert sha((root/'target/release/native_qualification.exe').read_bytes())==identities['fixed']['executable_sha256']
for name in ('LICENSE','SPOUTSDK/licence.txt'):
    members['execution-source/vendor/spout2-sys-0.1.1/vendor/Spout2/'+name] = (root/'vendor/spout2-sys-0.1.1/vendor/Spout2'/name).read_bytes()
validation = root/'target/qualification-reader-lease-validation-2026-10-30'
assert all(v['exit_code']==0 for v in load(validation/'results.json').values())
for path in validation.iterdir():
    members['validation/'+path.name] = path.read_bytes()
for name in ('qualification-reader-lease-repro-2026-10-30.log','qualification-reader-lease-fixed-2026-10-30.log',
             'reader_lease_reproducer_2026_10_30.rs','reader_lease_controls_2026_10_30.py',
             'validate_reader_lease_2026_10_30.py',Path(__file__).name):
    members['validation/'+name] = (root/'target'/name).read_bytes()
assert 'HRESULT(0x887A0001)' in (root/'target/qualification-reader-lease-repro-2026-10-30.log').read_text()
archive = destination/'mapgyver-m03-reader-lease-controls-2026-10-30.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,data in members.items():
        output.writestr(name,data)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None and len(check.namelist())==len(members)
    assert all(check.read(name)==data for name,data in members.items())
packet = {'schema_version':1,'native_artifact_schema_version':8,'date':'2026-10-30',
          'checkpoint':'Reuse slot-owned reader leases through latest renderer completion; preserve actual source fault causes',
          'source_baseline_commit':'18a841edcbc1f5c90c797a2404d05bef9ba00573',
          'acceptance':{'M03_done':7,'M03_total':9,'complete_phases':3,'total_phases':10,'qualification_gate_closed':False},
          'baseline':{'packet':baseline_path.relative_to(root).as_posix(),'sha256':sha(baseline_path.read_bytes()),'archive':baseline['archive']},
          'input_fingerprints':identities,'captures':reports,
          'reproducer':{'before_exit_code':101,'before_hresult':'0x887A0001','first_fixed_exit_code':0,
                        'definition_provenance':'reconstructed from the retained original test definition; no pre-run source fingerprint was captured',
                        'current_test':'copies the same static publication into two targets while retaining first ownership, verifies both exact images and latest-fence retirement, then separately verifies logical-fault cause recovery'},
          'archive':{'path':archive.relative_to(root).as_posix(),'bytes':archive.stat().st_size,'members':len(members),'sha256':sha(archive.read_bytes())},
          'validation':{'ordinary_rust_tests':154,'golden_native_tests':17,'app_native_tests':2,'python_tests':275,
                        'strict_golden_clippy':True,'release_build':True,'both_rust_formatters':True},
          'limitations':['two short diagnostics compared with published before controls; post-fix captures add PresentMon, so no isolated whole-renderer timing claim',
                         'before source 2 reported 0x887a0005, but old code manufactured that value for ownership faults; the trace cannot prove genuine device removal',
                         'source waits remain 2 ms per lock, renderer send waits remain zero; no added textures, copies, queues or source-pacing changes',
                         'software display observations do not establish physical scanout, GPU queue time or native buffer occupancy',
                         'cross-context GPU critical path, prescribed cadence/interruption/growth and genuine removal/stuck retirement remain open']}
with (destination/'mapgyver-m03-reader-lease-2026-10-30.json').open('x',encoding='utf-8',newline='\n') as output:
    json.dump(packet,output,indent=2,allow_nan=False)
    output.write('\n')
print(json.dumps({'archive':packet['archive'],'phase_audits':[{'phase':r['phase'],'scenario':r['scenario'],'audits':r['phase_audits']} for r in reports]}))
