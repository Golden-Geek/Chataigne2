"""Independently reconstruct raw same-clock partitions and package immutable controls."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'docs/progress/evidence'
members, captures, identities = {}, [], []


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(token):
    device = token['device']
    return device['runtime'], device['generation'], token['serial']


def stats(values):
    ordered = sorted(values)
    count = len(ordered)
    def rank(percent):
        return ordered[(count*percent+99)//100-1]
    return {'samples': count, 'median_ms': rank(50), 'p95_ms': rank(95),
            'p99_ms': rank(99), 'maximum_ms': ordered[-1]}


for scenario in ['Q01', 'Q02']:
    directory = ROOT / f'target/qualification-{scenario.lower()}-gpu-stages-2026-10-29'
    parent = load(directory / 'analysis.json')
    assert parent['schema_version'] == 7 and parent['qualified'] is False
    capture = parent['captures'][0]
    assert capture['manifest']['adapter'] == {'high': 0, 'low': 93226}
    assert capture['input_fingerprints']['unchanged']
    before = capture['input_fingerprints']['before']
    assert before == capture['input_fingerprints']['after']
    identities.append(before)
    for name, digest in before['execution_input_sha256'].items():
        assert sha((ROOT / name).read_bytes()) == digest, name
    assert sha((ROOT / 'target/release/native_qualification.exe').read_bytes()) == before['executable_sha256']
    raw = directory / 'sample-001'
    for name, digest in capture['raw_sha256'].items():
        assert sha((raw/name).read_bytes()) == digest, name
    summary = load(raw/'renderer-summary.json')
    window = next(v for v in summary['phase_windows'] if v['name'] == 'sample')
    rows = [json.loads(line) for line in (raw/'renderer.jsonl').read_text().splitlines()]
    frames, gpu = [], {}
    for entry in rows:
        if entry['kind'] != 'diagnostic':
            continue
        event = entry['event']
        if 'FrameCpu' in event:
            frame = event['FrameCpu']
            if window['begin_qpc'] <= frame['wall']['begin'] < window['end_qpc']:
                frames.append(identity(frame['token']))
        if 'Gpu' in event and event['Gpu']['context'] == 'Renderer':
            row = event['Gpu']
            key = identity(row['token'])
            assert key not in gpu
            gpu[key] = row
    report = capture['renderer_gpu']['stage_partitions']
    analyzed = {identity(row['token']): row for row in report['records']}
    assert len(frames) == len(set(frames)) == len(analyzed) == report['expected_batches'] == 300
    intervals = {name: [] for name in ('inputs', 'render', 'outputs')}
    largest = Counter()
    for key in frames:
        row = gpu[key]
        assert row['status'] == 'Valid' and row['frequency'] > 0
        points = [row[name] for name in ('begin', 'renderer_inputs_end', 'renderer_render_end', 'end')]
        assert all(type(v) is int and 0 <= v < (1 << 64) for v in points)
        assert points == sorted(points)
        ticks = [right-left for left, right in zip(points, points[1:])]
        assert sum(ticks) == row['end']-row['begin']
        values = {name: value*1000/row['frequency'] for name, value in zip(intervals, ticks)}
        assert analyzed[key]['stage_ms'] == values and analyzed[key]['missing'] is None
        for name, value in values.items():
            intervals[name].append(value)
        maximum = max(ticks)
        largest['tied' if ticks.count(maximum) > 1 else list(intervals)[ticks.index(maximum)]] += 1
    assert report['coverage_complete'] and report['covered_batches'] == 300
    assert dict(largest) == report['largest_stage_counts']
    assert {name: stats(v) for name, v in intervals.items()} == report['stages']
    cohort = capture['spout_output_cohort']
    captures.append({
        'scenario': scenario, 'manifest': capture['manifest'], 'raw_sha256': capture['raw_sha256'],
        'capture_execution_inputs_unchanged': True, 'executable_sha256': before['executable_sha256'],
        'renderer_gpu': {k: v for k, v in capture['renderer_gpu'].items() if k != 'stage_partitions'},
        'stage_partitions': {k: v for k, v in report.items() if k != 'records'},
        'outputs': capture['outputs'], 'producers': capture['producers'],
        'spout': {k: cohort[k] for k in ('expected_accepted_images', 'captured_images', 'missing_images',
                                       'invalid_captures', 'coverage_complete', 'source_age')},
        'independent_audit': {'exact_raw_partitions_agree': True, 'frames_verified': len(frames),
                              'distribution_and_largest_stage_agree': True},
        'criteria': capture['criteria'], 'qualified': False,
    })
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            members['native/' + path.relative_to(ROOT/'target').as_posix()] = path.read_bytes()

assert identities[0]['execution_input_sha256'] == identities[1]['execution_input_sha256']
assert identities[0]['executable_sha256'] == identities[1]['executable_sha256']
validation = ROOT / 'target/qualification-gpu-stages-validation-2026-10-29'
assert all(row['exit_code'] == 0 for row in load(validation/'results-final.json'))
original = load(validation/'results.json')
assert original[0]['exit_code'] == original[1]['exit_code'] == 0
for path in sorted(validation.iterdir()):
    members['validation/' + path.name] = path.read_bytes()
for script in [Path(__file__), ROOT/'target/validate_gpu_stages_2026_10_29.py']:
    members['validation/' + script.name] = script.read_bytes()

archive = DEST/'mapgyver-m03-gpu-stages-controls-2026-10-29.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in members.items():
        output.writestr(name, data)
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None and len(output.namelist()) == len(members)
    assert all(output.read(name) == data for name, data in members.items())
packet = {
    'schema_version': 1, 'native_artifact_schema_version': 7, 'date': '2026-10-29',
    'source_baseline_commit': identities[0]['git_head'],
    'checkpoint': 'Bounded same-clock renderer GPU stage partitions',
    'acceptance': {'M03_done': 7, 'M03_total': 9, 'complete_phases': 3, 'total_phases': 10,
                   'qualification_gate_closed': False},
    'archive': {'path': archive.relative_to(ROOT).as_posix(), 'sha256': sha(archive.read_bytes()),
                'bytes': archive.stat().st_size, 'members': len(members)},
    'execution_input_sha256': identities[0]['execution_input_sha256'],
    'executable_sha256': identities[0]['executable_sha256'],
    'validation': {'regular_library_tests': 148, 'public_integration_tests': 4, 'native_tests': 13,
                   'final_focused_native_timing_tests': 2, 'production_python_tests': 92,
                   'strict_clippy': True, 'final_release_runner_build': True, 'both_rust_formatters': True,
                   'clippy_repair': 'collapse an equivalent nested conditional; initial failure and final success retained'},
    'captures': captures,
    'next_action': 'Target output conversion/delivery, the largest interval in 271/300 Q02 frames',
    'limitations': ['short diagnostic controls do not replace the prescribed three-sample series',
                    'elapsed intervals include GPU waits, scheduling and command-feed gaps',
                    'no active-work, calibrated queue, native-buffer occupancy or cross-context critical path claim',
                    'no PresentMon collector; previous display/deadline evidence remains immutable',
                    'Q02 cadence and incomplete capture failures remain open; no budget or denominator changes'],
}
path = DEST/'mapgyver-m03-gpu-stages-2026-10-29.json'
with path.open('x', encoding='utf-8', newline='\n') as output:
    json.dump(packet, output, indent=2, allow_nan=False)
    output.write('\n')
print(json.dumps({'archive': packet['archive'], 'independent_partitions_verified': 600,
                  'execution_inputs_verified': len(packet['execution_input_sha256'])}))
