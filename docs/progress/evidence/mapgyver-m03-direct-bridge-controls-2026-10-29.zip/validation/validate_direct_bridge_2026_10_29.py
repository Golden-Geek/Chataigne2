from pathlib import Path
import json
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
directory = root/(sys.argv[1] if len(sys.argv) > 1 else 'target/qualification-direct-bridge-validation-2026-10-29')
directory.mkdir(exist_ok=False)
commands = [
    ('regular-tests', ['cargo','test','-p','golden_video','--features','qualification','--lib',
                      '--test','public_plan','--test','preview_typescript','--test','asset_preparation',
                      '--','--test-threads=1']),
    ('native-tests', ['cargo','test','-p','golden_video','--features','qualification','--lib',
                     '--','--ignored','--test-threads=1','--nocapture']),
    ('app-native-tests', ['cargo','test','-p','MapGyver','--features','native-qualification',
                         '--test','channel_rendering','--test','picture_rendering',
                         '--','--ignored','--test-threads=1','--nocapture']),
    ('clippy', ['cargo','clippy','-p','golden_video','--features','qualification','--all-targets',
               '--','-D','warnings']),
    ('python-tests', [sys.executable,'-B','-m','unittest','discover','-s','tools/mapgyver/tests',
                     '-p','test_production*.py']),
]
results = []
for name, command in commands:
    with (directory/(name+'.log')).open('xb') as output:
        result = subprocess.run(command,cwd=root,stdout=output,stderr=subprocess.STDOUT)
    results.append(dict(name=name,command=command,exit_code=result.returncode))
    (directory/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    if result.returncode: sys.exit(result.returncode)
