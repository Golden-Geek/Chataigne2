"""Verify fixed scenes, direct-bridge marker lineage, resource accounting and immutable inputs."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT/'docs/progress/evidence'
BASE = DEST/'mapgyver-m03-direct-window-2026-10-29.json'
baseline = json.loads(BASE.read_text())
members, captures, identities = {}, [], []
load = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
key = lambda token: (token['device']['runtime'], token['device']['generation'], token['serial'])
image = lambda value: (value['shared_handle'], value['frame'])

archive = ROOT/baseline['archive']['path']
assert sha(archive.read_bytes()) == baseline['archive']['sha256']
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name in z.namelist():
        if name.startswith('native/'):
            assert z.read(name) == (ROOT/'target'/name[len('native/'):]).read_bytes()

for scenario in ['Q01', 'Q02']:
    parent = ROOT/f'target/qualification-{scenario.lower()}-direct-bridge-2026-10-29'
    raw = parent/'sample-001'
    analysis = load(parent/'analysis.json')
    current = analysis['captures'][0]
    previous = next(c for c in baseline['captures'] if c['scenario'] == scenario)
    assert analysis['schema_version'] == 7 and analysis['qualified'] is False
    assert current['manifest']['adapter'] == {'high': 0, 'low': 93226}
    for name in ['adapter','scenario','sample_seconds','warmup_seconds','independence_seconds']:
        assert current['manifest'][name] == previous['manifest'][name]
    fingerprints = current['input_fingerprints']
    assert fingerprints['unchanged'] and fingerprints['before'] == fingerprints['after']
    identities.append(fingerprints['before'])
    for name, digest in fingerprints['before']['execution_input_sha256'].items():
        assert sha((ROOT/name).read_bytes()) == digest, name
    assert sha((ROOT/'target/release/native_qualification.exe').read_bytes()) == fingerprints['before']['executable_sha256']
    for name, digest in current['raw_sha256'].items(): assert sha((raw/name).read_bytes()) == digest
    rows = [json.loads(line) for line in (raw/'renderer.jsonl').read_text().splitlines()]
    events = [r['event'] for r in rows if r['kind'] == 'diagnostic']
    window = next(r for r in load(raw/'renderer-summary.json')['phase_windows'] if r['name'] == 'sample')
    inside = lambda qpc: window['begin_qpc'] <= qpc < window['end_qpc']
    gpu = {key(e['Gpu']['token']): e['Gpu'] for e in events if 'Gpu' in e and e['Gpu']['context'] == 'Renderer'}
    partitions = current['renderer_gpu']['stage_partitions']
    assert partitions['coverage_complete'] and partitions['covered_batches'] == 300
    for record in partitions['records']:
        r = gpu[key(record['token'])]
        assert r['status'] == 'Valid' and r['frequency'] > 0
        points = [r[k] for k in ['begin','renderer_inputs_end','renderer_render_end','end']]
        assert all(type(x) is int for x in points) and points == sorted(points)
        ticks = [b-a for a,b in zip(points,points[1:])]
        assert sum(ticks) == r['end']-r['begin']
        assert record['stage_ms'] == dict(zip(['inputs','render','outputs'],[x*1000/r['frequency'] for x in ticks]))
    producers = []
    source_bytes = 0
    for number in [1,2]:
        source = [json.loads(line) for line in (raw/f'source-{number}.jsonl').read_text().splitlines()]
        descriptor = next(r['source']['descriptor'] for r in source if r['kind'] == 'source_config')
        source_bytes += descriptor['extent']['width']*descriptor['extent']['height']*4
        versions = {}
        for r in source:
            if r['kind'] == 'source_frame' and r['submission']['outcome'] == 'Accepted':
                version = image(r['submission']['spout_image'])
                assert version not in versions
                versions[version] = r
        producers.append(versions)
    uses = {(key(e['SourceUse']['token']),e['SourceUse']['texture']):e['SourceUse'] for e in events if 'SourceUse' in e}
    consumer = [json.loads(line)['frame'] for line in (raw/'consumer.jsonl').read_text().splitlines()
                if json.loads(line)['kind'] == 'consumer_frame']
    accepted = [e['Output'] for e in events if 'Output' in e and e['Output']['output'] == 2
                and e['Output']['outcome'] == 'Accepted' and inside(e['Output']['delivery']['end'])]
    assert len(accepted) == 300
    for output in accepted:
        expected = [producers[n][image(uses[key(output['token']),n+1]['publication']['spout_image'])] for n in range(2)]
        matches = [c for c in consumer if c['spout_image'] and image(c['spout_image']) == image(output['spout_image'])]
        assert matches
        for frame in matches:
            assert frame['raw_words'] == expected[0]['marker_words']+expected[1]['marker_words']
            assert frame['left'] == {'Ok':expected[0]['submission']['stamp']}
            assert frame['right'] == {'Ok':expected[1]['submission']['stamp']}
    snapshots = [r['runtime']['resources'] for r in rows if r['kind'] == 'snapshot' and r['runtime']['resources']]
    base = min(r['bytes_used']-r['active']['bytes'] for r in snapshots
               if r['initialized'] and r['active'] and r['prepared'] == r['retiring'] == 0)
    peak = current['resources']['logical_reserved_peak_bytes']
    generation = next(r['active']['bytes'] for r in snapshots if r['active'])
    assert (peak-base) % generation == 0
    expected_base = 80179264 if scenario == 'Q01' else 254361664
    assert base == expected_base and source_bytes*4 < source_bytes*5
    expected_peak = 144691264 if scenario == 'Q01' else 575078464
    assert peak == expected_peak and peak < current['resources']['logical_workload_ceiling_bytes']
    captures.append({'scenario':scenario,'manifest':current['manifest'],
        'renderer_gpu':{k:v for k,v in current['renderer_gpu'].items() if k != 'stage_partitions'},
        'stage_partitions':{k:v for k,v in partitions.items() if k != 'records'},
        'outputs':current['outputs'],'producers':current['producers'],
        'spout':{k:v for k,v in current['spout_output_cohort'].items() if k not in ['records','source_publication_age']},
        'resources':{'input_reservation_bytes':source_bytes*4,'previous_input_reservation_bytes':source_bytes*5,
                     'baseline_bytes':base,'peak_bytes':peak,'full_generation_bytes':generation,
                     'peak_generation_charge_equivalents':(peak-base)//generation},
        'independent_audit':{'gpu_partitions_verified':300,'exact_spout_images_verified':300,
                             'raw_bytes_and_execution_inputs_unchanged':True},
        'criteria':current['criteria'],'raw_sha256':current['raw_sha256'],'qualified':False})
    for path in sorted(parent.rglob('*')):
        if path.is_file(): members['native/'+path.relative_to(ROOT/'target').as_posix()] = path.read_bytes()

assert identities[0]['execution_input_sha256'] == identities[1]['execution_input_sha256']
assert identities[0]['executable_sha256'] == identities[1]['executable_sha256']
for directory in ['qualification-direct-bridge-validation-2026-10-29','qualification-direct-bridge-final-validation-2026-10-29']:
    folder = ROOT/'target'/directory
    if 'final' in directory: assert all(r['exit_code'] == 0 for r in load(folder/'results.json'))
    for path in sorted(folder.iterdir()): members['validation/'+directory+'/'+path.name] = path.read_bytes()
for path in [Path(__file__),ROOT/'target/validate_direct_bridge_2026_10_29.py']:
    members['validation/'+path.name] = path.read_bytes()
archive = DEST/'mapgyver-m03-direct-bridge-controls-2026-10-29.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in members.items(): z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(members)
    assert all(z.read(name) == data for name,data in members.items())
packet = {'schema_version':1,'native_artifact_schema_version':7,'capture_date':'2026-10-29',
    'handoff_date':'2026-10-30','source_baseline_commit':identities[0]['git_head'],
    'checkpoint':'Direct receive into leased input bridge and canonical storage admission',
    'acceptance':{'M03_done':7,'M03_total':9,'complete_phases':3,'total_phases':10,'qualification_gate_closed':False},
    'baseline':{'packet':BASE.relative_to(ROOT).as_posix(),'sha256':sha(BASE.read_bytes()),
                'archive':baseline['archive'],'captures':baseline['captures']},
    'archive':{'path':archive.relative_to(ROOT).as_posix(),'sha256':sha(archive.read_bytes()),
               'bytes':archive.stat().st_size,'members':len(members)},
    'execution_input_sha256':identities[0]['execution_input_sha256'],
    'executable_sha256':identities[0]['executable_sha256'],
    'validation':{'ordinary_rust_tests':153,'golden_native_tests':15,'app_native_tests':2,
                   'production_python_tests':92,'strict_clippy':True,'both_rust_formatters':True,
                   'final_release_runner_build':True},'captures':captures,
    'limitations':['short sequential controls; no full qualification or broad causal claim',
        'producer/editor cadence and GPU/queue/growth/genuine-removal gates remain open',
        'higher Q02 total logical peak and mixed producer/age results are retained',
        'no physical-residency, active-GPU-work, critical-path or new display-age claim']}
with (DEST/'mapgyver-m03-direct-bridge-2026-10-29.json').open('x',encoding='utf-8',newline='\n') as out:
    json.dump(packet,out,indent=2,allow_nan=False); out.write('\n')
print(json.dumps({'archive':packet['archive'],'verified_gpu_partitions':600,'verified_exact_spout_images':600}))
