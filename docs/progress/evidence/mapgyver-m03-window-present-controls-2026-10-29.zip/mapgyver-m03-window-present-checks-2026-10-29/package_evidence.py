"""Independent raw CSV/native/source joins and bounded window-observation evidence packet."""
from collections import defaultdict
from copy import deepcopy
from fractions import Fraction
import base64
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[2]
CHECKS = Path(__file__).resolve().parent
EVIDENCE = ROOT/'docs/progress/evidence'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def key(value):
    return json.dumps(value, sort_keys=True)


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def distribution(values):
    if not values:
        return None
    values = sorted(values)
    return {'samples': len(values), 'median_ms': values[math.ceil(len(values)*.5)-1],
            'p95_ms': values[math.ceil(len(values)*.95)-1], 'p99_ms': values[math.ceil(len(values)*.99)-1],
            'maximum_ms': values[-1]}


def audit(directory, capture):
    report = read(directory/'presentmon.json')
    for field, suffix in [('stdout', 'stdout.csv'), ('stderr', 'stderr.log')]:
        raw = base64.b64decode(report[field+'_raw']['base64'], validate=True)
        assert hashlib.sha256(raw).hexdigest() == report[field+'_raw']['sha256']
        assert raw == (directory.parent/('sample-001-presentmon-'+suffix)).read_bytes()
        codec = 'utf-16' if report[field+'_raw']['encoding'] == 'utf-16-bom' else 'utf-8-sig'
        assert raw.decode(codec) == report[field]
    events = [row['event'] for row in rows(directory/'renderer.jsonl') if row['kind'] == 'diagnostic']
    outputs = [e['Output'] for e in events if 'Output' in e]
    calls = [o for o in outputs if o.get('window_present') is not None]
    uses = {(key(e['SourceUse']['token']), e['SourceUse']['texture']): e['SourceUse']
            for e in events if 'SourceUse' in e}
    producers = []
    for index in (1, 2):
        images = defaultdict(list)
        for row in rows(directory/f'source-{index}.jsonl'):
            if row['kind'] == 'source_frame' and row['submission']['spout_image']:
                images[key(row['submission']['spout_image'])].append(row)
        producers.append(images)
    csv_rows = list(csv.DictReader(io.StringIO(report['stdout'])))
    mapped, unmatched = {}, []
    for row in csv_rows:
        assert int(row['ProcessID']) == capture['manifest']['pid']
        pointer, qpc = int(row['SwapChainAddress'], 16), int(row['QPCTime'])
        matches = [o for o in calls if pointer in o['window_present']['addresses']
                   and o['consumer_api']['begin'] <= qpc <= o['consumer_api']['end']]
        if not matches:
            unmatched.append({'address': hex(pointer), 'present_qpc': qpc})
            continue
        assert len(matches) == 1
        match = matches[0]
        identity = key(match['token']), match['output']
        assert identity not in mapped
        mapped[identity] = row
    assert unmatched == capture['window_presentation']['unmatched_rows']
    assert len(csv_rows) == capture['window_presentation']['csv_rows']
    phase = next(p for p in read(directory/'renderer-summary.json')['phase_windows'] if p['name'] == 'sample')
    frequency = capture['manifest']['qpc_frequency']
    observed = []
    for output_report in capture['window_presentation']['outputs']:
        selected = [o for o in outputs if o['output'] == output_report['output'] and o['outcome'] == 'Accepted'
                    and phase['begin_qpc'] <= o['delivery']['end'] < phase['end_qpc']]
        assert len(selected) == output_report['expected_accepted_images']
        ages, publication_ages, delays = [[], []], [[], []], []
        missing = dropped = unknown = missing_sources = 0
        for output, record in zip(selected, output_report['records'], strict=True):
            assert record['token'] == output['token']
            row = mapped.get((key(output['token']), output['output']))
            if row is None:
                missing += 1
                assert record['present_qpc'] is None
                continue
            qpc = int(row['QPCTime'])
            assert record['present_qpc'] == qpc
            if row['Dropped'] == '1':
                dropped += 1
                assert record['display_qpc'] is None
                continue
            until = row['msUntilDisplayed']
            if until in ('NA', '0', '0.0') or Fraction(until) <= 0:
                unknown += 1
                assert record['display_qpc'] is None
                continue
            displayed = Fraction(qpc)+Fraction(until)*frequency/1000
            assert record['display_qpc'] == {'numerator': str(displayed.numerator), 'denominator': str(displayed.denominator)}
            delays.append(float((displayed-qpc)*1000/frequency))
            source_rows, pubs = [], []
            for index in range(2):
                use = uses.get((key(output['token']), index+1))
                pub = use.get('publication') if use else None
                candidates = producers[index].get(key(pub['spout_image']), []) if pub else []
                if not use or not use['sequence'] or len(candidates) != 1:
                    source_rows = []
                    break
                source_rows.append(candidates[0])
                pubs.append(pub)
            if not source_rows:
                missing_sources += 1
                assert record['source_age_ms'] is None
                continue
            calculated = [float((displayed-r['submission']['stamp']['qpc'])*1000/frequency) for r in source_rows]
            assert calculated == record['source_age_ms']
            for index in range(2):
                ages[index].append(calculated[index])
                publication_ages[index].append(float((displayed-pubs[index]['publication_qpc'])*1000/frequency))
        assert (missing, dropped, unknown, missing_sources) == tuple(output_report[k] for k in
               ('missing_rows', 'dropped', 'display_time_unavailable', 'missing_sources'))
        assert [distribution(v) for v in ages] == output_report['source_to_software_display_age']
        assert [distribution(v) for v in publication_ages] == output_report['publication_to_software_display_age']
        assert distribution(delays) == output_report['present_to_software_display']
        observed.append({'output': output_report['output'], 'accepted': len(selected), 'missing_csv': missing,
                         'dropped': dropped, 'unknown_display': unknown, 'missing_sources': missing_sources,
                         'source_age_distributions_recomputed': True})
    return {'raw_csv_rows': len(csv_rows), 'exact_api_joins': len(mapped), 'unmatched': len(unmatched),
            'raw_utf16_streams_preserved': True, 'sample_outputs': observed}


tests = [line for line in (CHECKS/'full-native-stdout.log').read_text().splitlines() if line.startswith('test result:')]
assert sum(int(re.search(r'(\d+) passed;', line)[1]) for line in tests) == 194
assert all('0 failed; 0 ignored;' in line for line in tests)
assert 'Finished `release` profile' in (CHECKS/'release-stderr.log').read_text()
captures, roots, audits = [], [], {}
for scenario in ('q01', 'q02'):
    root = ROOT/f'target/qualification-{scenario}-window-present-utf16-2026-10-29'
    roots.append(root)
    c = read(root/'analysis.json')['captures'][0]
    assert c['manifest']['schema_version'] == 6 and c['input_fingerprints']['unchanged']
    for path, expected in c['input_fingerprints']['before']['execution_input_sha256'].items():
        assert sha(ROOT/path) == expected, path
    assert c['input_fingerprints']['before']['external_trace_tools'] == c['input_fingerprints']['after']['external_trace_tools']
    assert all(role['complete'] for role in c['criteria']['telemetry_coverage']['roles'])
    summary = read(root/'sample-001/renderer-summary.json')
    parent = read(root/'sample-001/parent-summary.json')
    assert summary['retirement']['actual_retirement']
    assert summary['final_runtime']['resources']['bytes_used'] == summary['final_runtime']['resources']['in_flight'] == 0
    assert all(child['success'] and not child['forced'] for child in parent['children'])
    audits[scenario.upper()] = audit(root/'sample-001', c)
    c['retirement'] = summary['retirement']
    c['trace_capture'] = {k: v for k, v in read(root/'sample-001/presentmon.json').items()
                          if k not in ('stdout', 'stderr', 'stdout_raw', 'stderr_raw')}
    c = deepcopy(c)
    c.pop('other_contexts')
    c['spout_output_cohort'].pop('records')
    for phase in c['independence']['phases']:
        phase['spout_output_cohort'].pop('records')
    for output in c['window_presentation']['outputs']:
        output.pop('records')
    captures.append(c)
failed = ROOT/'target/qualification-q01-window-present-2026-10-29'
roots.append(failed)
(CHECKS/'independent-audit.json').write_text(json.dumps(audits, indent=2)+'\n', encoding='utf-8', newline='\n')
archive = EVIDENCE/'mapgyver-m03-window-present-controls-2026-10-29.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root in [*roots, CHECKS]:
        for path in sorted(root.rglob('*')):
            if path.is_file():
                z.write(path, path.relative_to(ROOT/'target').as_posix())
packet = {
    'schema_version': 1, 'artifact_schema_version': 6, 'date': '2026-10-29',
    'checkpoint': 'Exact native window Present to ETW software-display/source-age observations',
    'source_baseline_commit': 'dcd3d2e64bb51a545a4e43ada63cabe52b1f3c22',
    'acceptance': {'M03_done': 7, 'M03_total': 9, 'complete_phases': 3, 'total_phases': 10, 'qualification_gate_closed': False},
    'archive': {'path': archive.relative_to(ROOT).as_posix(), 'bytes': archive.stat().st_size,
                'sha256': sha(archive), 'members': len(zipfile.ZipFile(archive).namelist())},
    'validation': {'regular_rust_tests': 182, 'explicit_native_gpu_tests': 12, 'production_python_tests': 73,
                   'rust_results': tests, 'strict_default_and_native_all_target_clippy': True,
                   'release_x64_build': True, 'root_and_golden_core_formatters': True,
                   'generated_fixture_contracts_checked': True, 'independent_raw_reconstruction': audits},
    'scope': {'adapter': 'Intel adapter0 LUID 00000000:00016c2a', 'samples_per_scenario_after_decoder_fix': 1,
              'warmup_seconds': 5, 'sample_seconds': 3, 'isolation_seconds_per_phase': 1,
              'collector_tail_seconds': 40, 'sdk_changed': False,
              'driver_display_overlay_settings_changed': False, 'scenes_budgets_queue_depth_polling_changed': False},
    'failed_finalization': read(failed/'collector-finalization-failure.json'),
    'limitations': ['Short diagnostic controls are not prescribed qualification or a causal performance comparison.',
                    'Software display observations do not prove physical scanout, window pixel identity or optical latency.',
                    'Live ETW loss query covers native API calls but not final collector shutdown; final warnings remain separate.',
                    'Pending software-display events are not app/native buffer occupancy or calibrated GPU queue time.',
                    'GPU critical path, complete recovery/growth/handle qualification and physical M05 observations remain open.'],
    'captures': captures,
}
destination = EVIDENCE/'mapgyver-m03-window-present-2026-10-29.json'
assert not destination.exists()
destination.write_text(json.dumps(packet, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({'archive': packet['archive'], 'audits': audits}))
