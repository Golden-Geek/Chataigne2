//! Publish shared images before issuing any window work, using a cold-prepared schedule.
use super::super::outputs::OutputPool;
use super::super::pipeline::Pipeline;
use super::super::timing::{DiagnosticEvent, OutputTrace, Recorder};
use super::D3d11Resources;
use crate::OutputId;
use crate::plan::{BlendMode, CompiledPlan, PlanOutput, SampleFilter};
use crate::runtime::CompletionToken;
use std::rc::Rc;
use windows::Win32::Graphics::Direct3D11::ID3D11DeviceContext;

pub(super) struct Submission<'a> {
    pub outputs: &'a mut OutputPool,
    pub context: &'a ID3D11DeviceContext,
    pub pipeline: &'a Pipeline,
    #[cfg(all(test, feature = "qualification"))]
    pub copy_tap: &'a mut Option<super::tests::copy_tap::Tap>,
}

pub(super) fn ordered_outputs(
    outputs: &[PlanOutput],
    mut is_window: impl FnMut(OutputId) -> bool,
) -> Box<[PlanOutput]> {
    // This is bounded by demanded outputs and runs once per prepared generation, never per frame.
    let mut ordered = outputs.to_vec();
    ordered.sort_unstable_by_key(|output| (is_window(output.id), output.id));
    ordered.into_boxed_slice()
}

impl Submission<'_> {
    pub(super) fn submit(
        self,
        resources: &D3d11Resources,
        plan: &CompiledPlan,
        token: CompletionToken,
        recorder: Option<&Recorder>,
    ) {
        debug_assert_eq!(resources.output_schedule.len(), plan.outputs().len());
        let context = self.context;
        let pipeline = self.pipeline;
        for output in &resources.output_schedule {
            let converted = resources.outputs.get(&output.id).map(Rc::as_ref);
            let descriptor = self.outputs.descriptor(output.id).expect("validated native output");
            let admission_begin = recorder.and_then(Recorder::stamp);
            let admission = self.outputs.admit(output.id, context, descriptor, token);
            let mut consumer_api = None;
            let mut window_present = None;
            let (conversion, delivery, outcome, spout_image) = match admission {
                Err(outcome) => (
                    None,
                    recorder.and_then(|recorder| recorder.interval(admission_begin)),
                    outcome,
                    None,
                ),
                Ok(mut admitted) => {
                    let conversion_begin = recorder.and_then(Recorder::stamp);
                    let source = &resources.textures[&output.source];
                    // Equal extents map texel centres exactly; avoid four-tap interpolation
                    // while retaining color/alpha conversion. Scaling stays linear.
                    let target = admitted.render_target(converted);
                    let filter = if source.descriptor.extent == target.descriptor.extent {
                        SampleFilter::Nearest
                    } else {
                        SampleFilter::Linear
                    };
                    pipeline.draw(context, source, None, target, 1.0, BlendMode::Normal, filter);
                    let conversion = recorder.and_then(|recorder| recorder.interval(conversion_begin));
                    #[cfg(all(test, feature = "qualification"))]
                    if let Some(tap) = self.copy_tap.as_mut()
                        && let Some(converted) = converted
                    {
                        let input = &resources.textures[&plan.external_textures()[0].id];
                        tap.record(context, input, converted, token);
                    }
                    let delivery_begin = recorder.and_then(Recorder::stamp);
                    let delivered = admitted.deliver(converted, recorder, &mut consumer_api);
                    window_present = delivered.window_present;
                    let delivery = recorder.and_then(|recorder| recorder.interval(delivery_begin));
                    (conversion, delivery, delivered.outcome, delivered.spout_image)
                }
            };
            if let Some(recorder) = recorder {
                recorder.push(DiagnosticEvent::Output(OutputTrace {
                    token,
                    output: output.id,
                    conversion,
                    delivery,
                    consumer_api,
                    outcome: outcome.into(),
                    spout_image,
                    window_present,
                }));
            }
        }
    }
}
#[cfg(test)]
mod tests;
