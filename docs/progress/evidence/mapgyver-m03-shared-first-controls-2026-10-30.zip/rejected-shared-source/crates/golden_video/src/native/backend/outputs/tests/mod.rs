use super::ordered_outputs;
use crate::plan::PlanOutput;
use crate::{OutputId, TextureId};
fn output(id: u64, source: u64) -> PlanOutput {
    PlanOutput {
        id: OutputId::new(id).unwrap(),
        source: TextureId::new(source).unwrap(),
    }
}
fn pairs(outputs: &[PlanOutput]) -> Vec<(OutputId, TextureId)> {
    outputs.iter().map(|o| (o.id, o.source)).collect()
}
#[test]
fn shared_publication_does_not_depend_on_logical_output_id_order() {
    let authored = vec![output(1, 10), output(2, 20), output(3, 30)];
    let original = pairs(&authored);
    let ordered = ordered_outputs(&authored, |id| id != OutputId::new(2).unwrap());
    assert_eq!(pairs(&ordered), pairs(&[output(2, 20), output(1, 10), output(3, 30)]));
    assert_eq!(
        pairs(&authored),
        original,
        "native scheduling cannot mutate the logical plan"
    );
}
#[test]
fn multiple_shared_outputs_precede_every_window_and_preserve_sources() {
    let demanded = vec![output(4, 40), output(9, 90), output(21, 10), output(80, 30)];
    let ordered = ordered_outputs(&demanded, |id| {
        id == OutputId::new(4).unwrap() || id == OutputId::new(9).unwrap()
    });
    assert_eq!(
        pairs(&ordered),
        pairs(&[output(21, 10), output(80, 30), output(4, 40), output(9, 90)])
    );
    assert_eq!(ordered.len(), demanded.len(), "no demand is added or removed");
}
#[test]
fn no_output_demand_does_not_look_up_endpoints() {
    let ordered = ordered_outputs(&[], |_| panic!("unexpected endpoint lookup"));
    assert!(ordered.is_empty());
}
