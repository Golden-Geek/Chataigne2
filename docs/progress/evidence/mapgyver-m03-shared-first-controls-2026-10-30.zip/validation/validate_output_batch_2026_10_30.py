from pathlib import Path
import json
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
suffix = '-'+sys.argv[1] if len(sys.argv) > 1 else ''
directory = root/f'target/qualification-output-batch{suffix}-validation-2026-10-30'
directory.mkdir(exist_ok=False)
commands = {
    'root-format': ['cargo','fmt','--all'],
    'golden-core-format': ['cargo','fmt','--all','--manifest-path','crates/golden_core/Cargo.toml'],
    'regular-tests': ['cargo','test','--locked','-p','golden_video','--features','qualification'],
    'native-tests': ['cargo','test','--locked','-p','golden_video','--features','qualification','--lib','--','--ignored','--test-threads=1'],
    'app-native-tests': ['cargo','test','--locked','-p','MapGyver','--features','native-qualification','--test','channel_rendering','--test','picture_rendering','--','--ignored','--test-threads=1'],
    'clippy': ['cargo','clippy','--locked','-p','golden_video','--features','qualification','--all-targets','--','-D','warnings'],
    'release-build': ['cargo','build','--locked','--release','-p','MapGyver','--features','native-qualification','--bin','native_qualification'],
    'python-tests': [sys.executable,'-B','-m','unittest','discover','-s','tools/mapgyver/tests'],
    'diff-check': ['git','diff','--check'],
}
results = {}
for name, command in commands.items():
    print('starting',name,flush=True)
    with (directory/(name+'.log')).open('xb') as output:
        result = subprocess.run(command,cwd=root,stdout=output,stderr=subprocess.STDOUT,timeout=600)
    results[name] = {'command':command,'exit_code':result.returncode}
    with (directory/'results.json').open('w',encoding='utf-8') as output:
        json.dump(results,output,indent=2)
    print(name,result.returncode,flush=True)
    if result.returncode:
        print((directory/(name+'.log')).read_text(errors='replace')[-6000:])
        sys.exit(1)
