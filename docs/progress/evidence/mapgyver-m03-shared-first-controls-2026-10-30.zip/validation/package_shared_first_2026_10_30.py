"""Preserve native publication experiments, exact marker joins and CPU-order witnesses."""
from pathlib import Path
import hashlib
import json
import runpy
import subprocess
import zipfile

root = Path(__file__).resolve().parents[1]
destination = root/'docs/progress/evidence'
load = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
key = lambda token: (token['device']['runtime'],token['device']['generation'],token['serial'])
image = lambda version: (version['shared_handle'],version['frame'])
order = runpy.run_path(str(root/'tools/mapgyver/production_output_order.py'))['analyze_output_order']
baseline_path = destination/'mapgyver-m03-output-branch-2026-10-30.json'
baseline = load(baseline_path)
old_archive = root/baseline['archive']['path']
assert sha(old_archive.read_bytes()) == baseline['archive']['sha256']
members, reports, identities = {}, [], {}
for phase in ('baseline','staged','shared'):
    for scenario in ('Q01','Q02'):
        suffix = 'srgb-branch' if phase == 'baseline' else 'batch' if phase == 'staged' else 'shared'
        parent = root/f'target/qualification-{scenario.lower()}-output-{suffix}-2026-10-30'
        raw = parent/'sample-001'
        analysis = load(parent/'analysis.json')
        current = analysis['captures'][0]
        assert analysis['schema_version'] == 7 and not analysis['qualified']
        assert current['manifest']['adapter'] == {'high':0,'low':93226}
        assert tuple(current['manifest'][k] for k in ('warmup_seconds','sample_seconds','independence_seconds')) == (5,5,1)
        fingerprints = current['input_fingerprints']
        assert fingerprints['unchanged'] and fingerprints['before'] == fingerprints['after']
        identity = fingerprints['before']
        if phase in identities:
            assert identities[phase]['execution_input_sha256'] == identity['execution_input_sha256']
            assert identities[phase]['executable_sha256'] == identity['executable_sha256']
        identities[phase] = identity
        if phase in ('staged','shared'):
            source_root = root if phase == 'shared' else root/'target/qualification-output-staged-rejected-source-2026-10-30'
            for name,digest in identity['execution_input_sha256'].items():
                assert sha((source_root/name).read_bytes()) == digest,name
            if phase == 'shared':
                assert sha((root/'target/release/native_qualification.exe').read_bytes()) == identity['executable_sha256']
                for name in identity['execution_input_sha256']:
                    members['rejected-shared-source/'+name] = (root/name).read_bytes()
        if phase == 'baseline':
            with zipfile.ZipFile(old_archive) as previous:
                prefix = 'native/'+parent.name+'/'
                for name in previous.namelist():
                    if name.startswith(prefix):
                        assert previous.read(name) == (parent/name[len(prefix):]).read_bytes()
        for name,digest in current['raw_sha256'].items(): assert sha((raw/name).read_bytes()) == digest
        rows = [json.loads(line) for line in (raw/'renderer.jsonl').read_text().splitlines()]
        events = [row['event'] for row in rows if row['kind'] == 'diagnostic']
        window = next(row for row in load(raw/'renderer-summary.json')['phase_windows'] if row['name'] == 'sample')
        inside = lambda qpc: window['begin_qpc'] <= qpc < window['end_qpc']
        frames = [e['FrameCpu'] for e in events if 'FrameCpu' in e and e['FrameCpu']['wall'] and inside(e['FrameCpu']['wall']['begin'])]
        outputs = [e['Output'] for e in events if 'Output' in e]
        ordering = order(frames,outputs,healthy=current['criteria']['telemetry_coverage']['roles'][0]['complete'])
        assert ordering['expected_frames'] == 300 and ordering['unknown_frames'] == 0
        if phase == 'shared':
            assert ordering['ordering_verified'] and ordering == current['output_submission_order']
        else:
            assert not ordering['ordering_verified'] and ordering['frames_with_violations'] > 0
        members[f'order-audit/{phase}-{scenario}.json'] = (json.dumps(ordering,indent=2)+'\n').encode()
        gpu = {key(e['Gpu']['token']):e['Gpu'] for e in events if 'Gpu' in e and e['Gpu']['context'] == 'Renderer'}
        partitions = current['renderer_gpu']['stage_partitions']
        verified = 0
        for record in partitions['records']:
            if record['missing'] is not None: continue
            row = gpu[key(record['token'])]
            assert row['status'] == 'Valid' and row['frequency'] > 0
            points = [row[k] for k in ('begin','renderer_inputs_end','renderer_render_end','end')]
            assert points == sorted(points)
            ticks = [b-a for a,b in zip(points,points[1:])]
            assert sum(ticks) == row['end']-row['begin']
            assert record['stage_ms'] == dict(zip(('inputs','render','outputs'),[t*1000/row['frequency'] for t in ticks]))
            verified += 1
        uses = {(key(e['SourceUse']['token']),e['SourceUse']['texture']):e['SourceUse'] for e in events if 'SourceUse' in e}
        producers = []
        for number in (1,2):
            source = [json.loads(line) for line in (raw/f'source-{number}.jsonl').read_text().splitlines()]
            versions = {}
            for row in source:
                if row['kind'] == 'source_frame' and row['submission']['outcome'] == 'Accepted':
                    version = image(row['submission']['spout_image'])
                    assert version not in versions
                    versions[version] = row
            producers.append(versions)
        consumers = [json.loads(line)['frame'] for line in (raw/'consumer.jsonl').read_text().splitlines()
                     if json.loads(line)['kind'] == 'consumer_frame']
        accepted = [row for row in outputs if row['output'] == 2 and row['outcome'] == 'Accepted' and inside(row['delivery']['end'])]
        captured,missing = 0,[]
        for output in accepted:
            matches = [frame for frame in consumers if frame['spout_image'] and image(frame['spout_image']) == image(output['spout_image'])]
            if not matches:
                missing.append(output['token'])
                continue
            expected = [producers[n][image(uses[key(output['token']),n+1]['publication']['spout_image'])] for n in range(2)]
            for frame in matches:
                assert frame['raw_words'] == expected[0]['marker_words']+expected[1]['marker_words']
                assert frame['left'] == {'Ok':expected[0]['submission']['stamp']}
                assert frame['right'] == {'Ok':expected[1]['submission']['stamp']}
            captured += 1
        reports.append({'phase':phase,'scenario':scenario,'manifest':current['manifest'],
            'renderer_gpu':{k:v for k,v in current['renderer_gpu'].items() if k!='stage_partitions'},
            'stage_partitions':{k:v for k,v in partitions.items() if k!='records'},
            'outputs':current['outputs'],'producers':current['producers'],
            'spout':{k:v for k,v in current['spout_output_cohort'].items() if k not in ('records','source_publication_age')},
            'resources':{k:v for k,v in current['resources'].items() if k not in ('renderer_handle_counts','fixture_process_memory')},
            'shared_first_order':{k:v for k,v in ordering.items() if k!='records'},
            'recorded_order_schema':(current.get('output_submission_order') or {}).get('schema_version'),
            'independent_audit':{'gpu_partitions_verified':verified,'expected_spout_images':len(accepted),
                                 'exact_spout_images_verified':captured,'missing_images':missing},
            'criteria':current['criteria'],'raw_sha256':current['raw_sha256'],'qualified':False})
        if phase != 'baseline':
            for path in sorted(parent.rglob('*')):
                if path.is_file(): members['native/'+path.relative_to(root/'target').as_posix()] = path.read_bytes()
for folder in ('qualification-output-batch-validation-2026-10-30','qualification-output-batch-final-validation-2026-10-30',
               'qualification-output-batch-shared-validation-2026-10-30'):
    directory = root/'target'/folder
    if folder != 'qualification-output-batch-validation-2026-10-30':
        assert all(result['exit_code']==0 for result in load(directory/'results.json').values())
    for path in sorted(directory.iterdir()): members['validation/'+folder+'/'+path.name] = path.read_bytes()
rejected = root/'target/qualification-output-staged-rejected-source-2026-10-30'
for path in sorted(rejected.rglob('*')):
    if path.is_file(): members['rejected-staged-source/'+path.relative_to(rejected).as_posix()] = path.read_bytes()
for name in ('vendor/spout2-sys-0.1.1/vendor/Spout2/LICENSE','vendor/spout2-sys-0.1.1/vendor/Spout2/SPOUTSDK/licence.txt'):
    members['rejected-staged-source/'+name] = (root/name).read_bytes()
    members['rejected-shared-source/'+name] = (root/name).read_bytes()
members['rejected-shared-source/changes.patch'] = subprocess.check_output(['git','diff','--binary','HEAD'],cwd=root)
for name in ('validate_output_batch_2026_10_30.py','output_batch_controls_2026_10_30.py','preserve_staged_output_2026_10_30.py'):
    members['validation/'+name] = (root/'target'/name).read_bytes()
members['validation/'+Path(__file__).name] = Path(__file__).read_bytes()
archive = destination/'mapgyver-m03-shared-first-controls-2026-10-30.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for name,data in members.items(): output.writestr(name,data)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None and len(check.namelist())==len(members)
    assert all(check.read(name)==data for name,data in members.items())
packet = {'schema_version':1,'native_artifact_schema_version':7,'date':'2026-10-30',
    'checkpoint':'Reject staged and cold-prepared shared-first output schedules after regressed Q02 controls',
    'source_baseline_commit':'b68a5f0632e152c060096f13da118e7525ba604a',
    'acceptance':{'M03_done':7,'M03_total':9,'complete_phases':3,'total_phases':10,'qualification_gate_closed':False},
    'baseline':{'packet':baseline_path.relative_to(root).as_posix(),'sha256':sha(baseline_path.read_bytes()),'archive':baseline['archive']},
    'input_fingerprints':identities,'captures':reports,
    'archive':{'path':archive.relative_to(root).as_posix(),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(members)},
    'experiment_validation':{'ordinary_rust_tests':156,'golden_native_tests':17,'app_native_tests':2,'python_tests':274,
                  'strict_golden_clippy':True,'release_build':True,'both_rust_formatters':True},
    'decision':{'staged_schedule':'rejected','shared_first_schedule':'rejected',
                'reason':'Q02 renderer-context p95 regressed from 11.489583333333334 to 14.32515625 and 17.417708333333334 ms respectively; neither demonstrates a benefit worth retaining',
                'retained_renderer':'restore native execution sources byte-for-byte to b68a5f0632e152c060096f13da118e7525ba604a before delivery',
                'staged_execution_sources_retained':len(identities['staged']['execution_input_sha256']),
                'shared_execution_sources_retained':len(identities['shared']['execution_input_sha256'])},
    'limitations':['one short diagnostic run per scenario/variant; no prescribed-series qualification or isolated whole-renderer causal claim',
                   'ordering schema 1 in the staged capture records its former all-conversions-before-API experiment; derived schema 2 checks the rejected shared-first hypothesis, not a production acceptance requirement',
                   'CPU submission order does not measure GPU completion, queue delay, native occupancy or full critical path',
                   'context/stage GPU spans contain waits and command-feed gaps; stage percentiles are not added',
                   'producer admission, per-output deadlines, complete GPU path, growth and genuine removal/stuck retirement remain open']}
with (destination/'mapgyver-m03-shared-first-2026-10-30.json').open('x',encoding='utf-8',newline='\n') as output:
    json.dump(packet,output,indent=2,allow_nan=False)
    output.write('\n')
print(json.dumps({'archive':packet['archive'],'audit':[r['independent_audit'] for r in reports]}))
