//! Stage every admitted conversion before shared publication and window presentation.
use std::rc::Rc;
use windows::Win32::Graphics::Direct3D11::ID3D11DeviceContext;

use crate::plan::{BlendMode, CompiledPlan, PlanOutput, SampleFilter};
use crate::runtime::CompletionToken;

use super::super::outputs::{AdmittedOutput, Delivery, OutputPool};
use super::super::pipeline::Pipeline;
use super::super::timing::{CpuInterval, DiagnosticEvent, OutputTrace, Recorder};
use super::D3d11Resources;

pub(super) struct Submission<'a> {
    pub outputs: &'a mut OutputPool,
    pub context: &'a ID3D11DeviceContext,
    pub pipeline: &'a Pipeline,
    #[cfg(all(test, feature = "qualification"))]
    pub copy_tap: &'a mut Option<super::tests::copy_tap::Tap>,
}

struct Staged<'a, 'p> {
    output: &'p PlanOutput,
    admission: Result<AdmittedOutput<'a>, Delivery>,
    conversion: Option<CpuInterval>,
    rejected: Option<CpuInterval>,
}

impl Submission<'_> {
    pub(super) fn submit(
        self,
        resources: &D3d11Resources,
        plan: &CompiledPlan,
        token: CompletionToken,
        recorder: Option<&Recorder>,
    ) {
        let context = self.context;
        let pipeline = self.pipeline;
        let admissions = self.outputs.admissions(context, plan, token, recorder);
        stage_then_publish(
            admissions,
            |mut attempt| {
                let converted = resources.outputs.get(&attempt.output.id).map(Rc::as_ref);
                let conversion = if let Ok(admitted) = &mut attempt.admission {
                    let begin = recorder.and_then(Recorder::stamp);
                    let source = &resources.textures[&attempt.output.source];
                    let target = admitted.render_target(converted);
                    let filter = if source.descriptor.extent == target.descriptor.extent {
                        SampleFilter::Nearest
                    } else {
                        SampleFilter::Linear
                    };
                    pipeline.draw(context, source, None, target, 1.0, BlendMode::Normal, filter);
                    let interval = recorder.and_then(|r| r.interval(begin));
                    #[cfg(all(test, feature = "qualification"))]
                    if let Some(tap) = self.copy_tap
                        && let Some(converted) = converted
                    {
                        let input = &resources.textures[&plan.external_textures()[0].id];
                        tap.record(context, input, converted, token);
                    }
                    interval
                } else {
                    None
                };
                Staged {
                    output: attempt.output,
                    admission: attempt.admission,
                    conversion,
                    rejected: attempt.rejected,
                }
            },
            |staged| {
                (
                    staged.admission.as_ref().is_ok_and(AdmittedOutput::is_window),
                    staged.output.id,
                )
            },
            |staged| {
                let mut consumer_api = None;
                let (delivery, outcome, spout_image, window_present) = match staged.admission {
                    Err(outcome) => (staged.rejected, outcome, None, None),
                    Ok(admitted) => {
                        let begin = recorder.and_then(Recorder::stamp);
                        let converted = resources.outputs.get(&staged.output.id).map(Rc::as_ref);
                        let delivered = admitted.deliver(converted, recorder, &mut consumer_api);
                        (
                            recorder.and_then(|r| r.interval(begin)),
                            delivered.outcome,
                            delivered.spout_image,
                            delivered.window_present,
                        )
                    }
                };
                if let Some(recorder) = recorder {
                    recorder.push(DiagnosticEvent::Output(OutputTrace {
                        token,
                        output: staged.output.id,
                        conversion: staged.conversion,
                        delivery,
                        consumer_api,
                        outcome: outcome.into(),
                        spout_image,
                        window_present,
                    }));
                }
            },
        );
    }
}

fn stage_then_publish<A, T, K: Ord>(
    attempts: impl Iterator<Item = A>,
    stage: impl FnMut(A) -> T,
    order: impl FnMut(&T) -> K,
    publish: impl FnMut(T),
) {
    // Only demanded outputs enter this frame-local metadata buffer. Config validation bounds
    // fixed endpoints by max_outputs; no authored-graph scan or extra image/queue slot is added.
    let mut staged = attempts.map(stage).collect::<Vec<_>>();
    staged.sort_unstable_by_key(order);
    staged.into_iter().for_each(publish);
}

#[cfg(test)]
mod tests;
