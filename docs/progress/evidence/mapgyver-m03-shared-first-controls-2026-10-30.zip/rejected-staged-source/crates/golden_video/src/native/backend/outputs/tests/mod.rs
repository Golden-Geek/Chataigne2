use super::stage_then_publish;
use std::cell::RefCell;

#[test]
fn all_conversions_precede_publication_and_shared_outputs_precede_presents() {
    let events = RefCell::new(Vec::new());
    // Window IDs surround a shared output, matching the production qualification layout.
    let attempts = [(1, true), (2, false), (3, true)];
    stage_then_publish(
        attempts.into_iter(),
        |output| {
            events.borrow_mut().push(("convert", output.0));
            output
        },
        |&(id, window)| (window, id),
        |output| events.borrow_mut().push(("publish", output.0)),
    );
    assert_eq!(
        events.into_inner(),
        vec![
            ("convert", 1),
            ("convert", 2),
            ("convert", 3),
            ("publish", 2),
            ("publish", 1),
            ("publish", 3)
        ]
    );
}

#[test]
fn a_rejected_endpoint_does_not_skip_or_publish_another_endpoints_work() {
    let events = RefCell::new(Vec::new());
    stage_then_publish(
        [(1, true, false), (2, false, true), (3, true, true)].into_iter(),
        |output| {
            events
                .borrow_mut()
                .push((if output.2 { "convert" } else { "rejected" }, output.0));
            output
        },
        |&(id, window, _)| (window, id),
        |(id, _, admitted)| {
            events
                .borrow_mut()
                .push((if admitted { "publish" } else { "report" }, id))
        },
    );
    assert_eq!(
        events.into_inner(),
        vec![
            ("rejected", 1),
            ("convert", 2),
            ("convert", 3),
            ("publish", 2),
            ("report", 1),
            ("publish", 3)
        ]
    );
}

#[test]
fn no_demand_has_no_conversion_or_publication() {
    stage_then_publish(
        std::iter::empty::<u64>(),
        |_| panic!("unexpected conversion"),
        |&id| id,
        |_| panic!("unexpected publication"),
    );
}
