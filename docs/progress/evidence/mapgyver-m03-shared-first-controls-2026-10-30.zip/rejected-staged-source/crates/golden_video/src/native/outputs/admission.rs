use std::collections::btree_map::IterMut;
use std::iter::Peekable;
use std::slice;

use windows::Win32::Graphics::Direct3D11::{ID3D11Device, ID3D11DeviceContext};

use crate::OutputId;
use crate::plan::PlanOutput;
use crate::runtime::{CompletionToken, DeviceGeneration};

use super::super::observation::D3d11Control;
use super::super::timing::{CpuInterval, Recorder};
use super::{AdmittedOutput, Binding, Delivery, INVALID_ARGUMENT};

pub(super) struct Admissions<'a, 'p, 'c> {
    pub bindings: Peekable<IterMut<'a, OutputId, Binding>>,
    pub outputs: slice::Iter<'p, PlanOutput>,
    pub device: &'a ID3D11Device,
    pub context: &'c ID3D11DeviceContext,
    pub generation: DeviceGeneration,
    pub control: &'a D3d11Control,
    pub token: CompletionToken,
    pub stopping: bool,
    pub valid_context: bool,
    pub recorder: Option<&'c Recorder>,
}

pub(in crate::native) struct Attempt<'a, 'p> {
    pub output: &'p PlanOutput,
    pub admission: Result<AdmittedOutput<'a>, Delivery>,
    pub rejected: Option<CpuInterval>,
}

impl<'a, 'p> Iterator for Admissions<'a, 'p, '_> {
    type Item = Attempt<'a, 'p>;

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.outputs.size_hint()
    }

    fn next(&mut self) -> Option<Self::Item> {
        let output = self.outputs.next()?;
        let begin = self.recorder.and_then(Recorder::stamp);
        let admission = if !self.valid_context || self.token.device != self.generation {
            Err(Delivery::Failed(INVALID_ARGUMENT))
        } else {
            // Both collections are sorted by ID; visit each fixed endpoint at most once.
            while self.bindings.peek().is_some_and(|(id, _)| **id < output.id) {
                self.bindings.next();
            }
            if self.bindings.peek().is_some_and(|(id, _)| **id == output.id) {
                let (_, binding) = self.bindings.next().expect("matching binding");
                match binding.admit(self.device, self.context, self.stopping, self.token) {
                    Ok(()) => Ok(AdmittedOutput {
                        binding,
                        device: self.device,
                        generation: self.generation,
                        control: self.control,
                        token: self.token,
                    }),
                    Err(delivery) => {
                        binding.publish(self.control, self.generation);
                        self.control.observe_output(output.id, self.token, delivery);
                        Err(delivery)
                    }
                }
            } else {
                Err(Delivery::Unavailable)
            }
        };
        let rejected = admission
            .is_err()
            .then(|| self.recorder.and_then(|r| r.interval(begin)))
            .flatten();
        Some(Attempt {
            output,
            admission,
            rejected,
        })
    }
}

impl ExactSizeIterator for Admissions<'_, '_, '_> {}
