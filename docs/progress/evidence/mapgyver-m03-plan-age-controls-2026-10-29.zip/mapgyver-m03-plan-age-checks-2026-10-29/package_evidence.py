"""Independently reconstruct CPU lifecycle joins and package the bounded native controls."""

from collections import defaultdict
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[2]
CHECKS = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'docs/progress/evidence'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def key(value):
    return json.dumps(value, sort_keys=True)


def distribution(values):
    if not values:
        return None
    values = sorted(values)
    return {'samples': len(values), 'median_ms': values[math.ceil(len(values)*.5)-1],
            'p95_ms': values[math.ceil(len(values)*.95)-1],
            'p99_ms': values[math.ceil(len(values)*.99)-1], 'maximum_ms': values[-1]}


def independent_plan_audit(directory, capture):
    native = [row['event'] for row in map(json.loads, (directory/'renderer.jsonl').read_text().splitlines())
              if row['kind'] == 'diagnostic']
    transitions = [e['Plan'] for e in native if 'Plan' in e]
    frames = [e['FrameCpu'] for e in native if 'FrameCpu' in e]
    outputs = [e['Output'] for e in native if 'Output' in e]
    expected = capture['plan_publication_age']
    grouped = defaultdict(list)
    for trace in transitions:
        grouped[key(trace['identity'])].append(trace)
    assert len(grouped) == expected['accepted_publications']
    frequency = capture['manifest']['qpc_frequency']
    receipts, first_uses, installations = [], [], 0
    frame_by_token = {key(f['token']): f for f in frames}
    for recorded in expected['records']:
        rows = grouped[key(recorded['identity'])]
        published = [r['observed_qpc'] for r in rows if r['stage'] == 'Published']
        received = [r['observed_qpc'] for r in rows if r['stage'] == 'Received']
        assert len(published) == 1 and published[0] > 0
        actual_events = {r['stage'] if isinstance(r['stage'], str) else next(iter(r['stage'])):
                         r['observed_qpc'] for r in rows
                         if not isinstance(r['stage'], dict) or 'Installed' not in r['stage']}
        assert actual_events == recorded['events']
        assert len(received) <= 1
        if received:
            assert received[0] >= published[0]
            receipts.append((received[0]-published[0])*1000/frequency)
        for info in recorded['installations']:
            installations += 1
            generation = info['generation']
            installed = [r['observed_qpc'] for r in rows if r['stage'] == {'Installed': {'generation': generation}}]
            assert len(installed) == 1 and installed[0] == info['installed_qpc']
            assert len(received) == 1 and installed[0] >= received[0]
            used = [f for f in frames if f['generation'] == generation]
            assert len(used) == info['submitted_frames']
            if used:
                first = min(f['wall']['begin'] for f in used)
                assert first == info['first_submit_qpc'] and first >= installed[0]
                first_uses.append((first-published[0])*1000/frequency)
                assert first_uses[-1] == info['publication_to_first_submit_ms']
                assert (first-installed[0])*1000/frequency == info['install_to_first_submit_ms']
    assert installations == expected['installed_generations']
    assert distribution(receipts) == expected['publication_to_receipt']
    assert distribution(first_uses) == expected['publication_to_first_submit']
    summary = read(directory/'renderer-summary.json')
    window = next(w for w in summary['phase_windows'] if w['name'] == 'sample')
    for report in expected['outputs']:
        selected = [o for o in outputs if o['output'] == report['output'] and o['outcome'] == 'Accepted'
                    and window['begin_qpc'] <= o['delivery']['end'] < window['end_qpc']]
        ages = []
        for output in selected:
            frame = frame_by_token[key(output['token'])]
            plan = grouped[key(frame['generation']['identity'])]
            published = next(r['observed_qpc'] for r in plan if r['stage'] == 'Published')
            assert frame['wall']['begin'] <= output['consumer_api']['begin'] <= output['consumer_api']['end'] <= frame['wall']['end']
            ages.append((output['consumer_api']['end']-published)*1000/frequency)
        assert len(selected) == report['expected_accepted_calls'] and report['missing'] == 0
        assert distribution(ages) == report['publication_to_api_end']
    assert expected['coverage_complete'] and expected['unjoined_frame_rows'] == expected['unjoined_output_calls'] == 0
    return {'accepted_publications': len(grouped), 'recorded_installs': installations,
            'first_receipts': len(receipts), 'first_used_generations': len(first_uses),
            'raw_frame_joins': len(frames), 'all_recorded_durations_recomputed': True,
            'publication_to_receipt': distribution(receipts),
            'publication_to_first_submit': distribution(first_uses)}


test_lines = [line for line in (CHECKS/'full-native-stdout.log').read_text().splitlines()
              if line.startswith('test result:')]
assert sum(int(re.search(r'(\d+) passed;', line)[1]) for line in test_lines) == 194
assert all('0 failed; 0 ignored;' in line for line in test_lines)
assert 'Finished `release` profile' in (CHECKS/'release-stderr.log').read_text()

captures, roots, audits = [], [], {}
for scenario in ('q01', 'q02'):
    root = ROOT / f'target/qualification-{scenario}-plan-age-2026-10-29'
    roots.append(root)
    c = read(root/'analysis.json')['captures'][0]
    assert c['manifest']['schema_version'] == 5
    assert c['input_fingerprints']['unchanged']
    for path, expected in c['input_fingerprints']['before']['execution_input_sha256'].items():
        assert sha(ROOT/path) == expected, path
    assert all(role['complete'] for role in c['criteria']['telemetry_coverage']['roles'])
    assert c['renderer_gpu']['complete']
    summary = read(root/'sample-001/renderer-summary.json')
    parent = read(root/'sample-001/parent-summary.json')
    assert summary['retirement']['actual_retirement']
    assert summary['final_runtime']['state'] == 'Stopped'
    assert summary['final_runtime']['resources']['bytes_used'] == 0
    assert summary['final_runtime']['resources']['in_flight'] == 0
    assert all(child['success'] and not child['forced'] for child in parent['children'])
    audits[scenario.upper()] = independent_plan_audit(root/'sample-001', c)
    c['retirement'] = summary['retirement']
    c['owned_children'] = parent['children']
    c = deepcopy(c)
    c.pop('other_contexts')
    c['spout_output_cohort'].pop('records')
    for phase in c['independence']['phases']:
        phase['spout_output_cohort'].pop('records')
    captures.append(c)

(CHECKS/'independent-audit.json').write_text(json.dumps(audits, indent=2)+'\n', encoding='utf-8', newline='\n')
archive = EVIDENCE/'mapgyver-m03-plan-age-controls-2026-10-29.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root in [*roots, CHECKS]:
        for path in sorted(root.rglob('*')):
            if path.is_file():
                z.write(path, path.relative_to(ROOT/'target').as_posix())

packet = {
    'schema_version': 1, 'artifact_schema_version': 5, 'date': '2026-10-29',
    'checkpoint': 'Exact CPU plan publication, first receipt, installation and first-use observations',
    'source_baseline_commit': 'dc8777f9ee0f516e116d7a1598e4075b5d5aa32c',
    'acceptance': {'M03_done': 7, 'M03_total': 9, 'complete_phases': 3, 'total_phases': 10,
                   'qualification_gate_closed': False},
    'archive': {'path': archive.relative_to(ROOT).as_posix(), 'bytes': archive.stat().st_size,
                'sha256': sha(archive), 'members': len(zipfile.ZipFile(archive).namelist())},
    'validation': {'regular_rust_tests': 182, 'explicit_native_gpu_tests': 12,
                   'production_python_tests': 60, 'full_rust_results': test_lines,
                   'strict_default_and_native_all_target_clippy': True, 'release_x64_build': True,
                   'root_and_golden_core_formatters': True, 'generated_fixture_contracts_checked': True,
                   'independent_raw_plan_reconstruction': audits},
    'scope': {'adapter': 'Intel adapter0 LUID 00000000:00016c2a', 'samples_per_scenario': 1,
              'warmup_seconds': 1, 'sample_seconds': 3, 'isolation_seconds_per_phase': 1,
              'sdk_fork_changed': False, 'driver_display_overlay_settings_changed': False,
              'reference_scenes_budgets_queue_depth_polling_changed': False},
    'findings': [
        'The native recorder exists before worker startup, so first publication can be observed before native initialization.',
        'Published and first Received records follow the metadata mailbox lock; Core records every actual installation, including recovery of the same authored plan.',
        'First receipt is recorded once across preparation retry. Superseded unread inputs have no invented receipt, installation or zero-latency sample.',
        'CPU plan handoff/first-use and retained plan age at accepted output APIs are measured by exact authored/resource identities.',
        'Retained plan age grows between edits; it is not edit latency, GPU queue time, physical presentation age or a cross-context GPU critical path.',
        'Neither M03 native recovery nor full renderer qualification is closed by these bounded measurements.'
    ],
    'limitations': ['Only one short diagnostic sample per scenario; prescribed durations and repetitions remain open.',
                    'GPU/presentation queue, native-window age, critical path and environment pinning remain unavailable.',
                    'All missing lifecycle/counter/frame joins remain incomplete; existing failed captures and budgets are preserved.'],
    'captures': captures,
}
destination = EVIDENCE/'mapgyver-m03-plan-age-2026-10-29.json'
assert not destination.exists()
destination.write_text(json.dumps(packet, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({'archive': packet['archive'], 'audits': audits}))
